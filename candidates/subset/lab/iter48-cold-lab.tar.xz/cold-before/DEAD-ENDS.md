# Dead ends — latest decision gates

Exact prior DEAD-ENDS.md is retained in lab/iter39-historical-notebooks.tar.xz with
length/SHA256manifest. Restore it for full unabridged historical failure evidence.

Iteration39: common A/B caller-owned publication avoids iteration38 second chain
copy, real72Breturns, but neither exact N24screen positive. Mode1 sixparams
365.043157->362.191191(-0.781268%),10552hitsPASS;mode2 oneaddress/tag
402.934989->399.475950(-0.858461%),11645hitsPASS. Do not rerun unchanged for luck.
Native mode1 spills32Bstack;mode2 genuinely repairs zero stack/spills and reduces
14632->14552inst but remains above production14520. Both128regs24KiB. Nativeother5
kernelsidentical; alloff finalnativebyteidentical. No submission qualification.
Tagcontrol/experimentbothPoissonadvisoriesretained. Neither isolated screen can
support a claimed GPU-specific statistically significant subpercent slowdown.

See lab/ITER39-COMMON-PUBLICATION-REVIEW.md and manifests for concrete evidence.
Next test must materially change actual work/communication, or independently
justify an interaction hypothesis; no performance credit transfers from code
cleanup alone.


## Iter40 bottom down-sweep/leaf fusion

Exact N24PASS62898hits inclscreen andthree-arm qualification. +0.423%screen;
all3candidate395.549748M/s vsactualleader387.810532(+1.995618%)vsprod394.635123
(+0.231765%). Required>=4%localFAIL,no submission. Defaultoff, offnativebyteexact.
Native14520->14632/local14576->14696inst,128regs24KiB0stack0spill,other5kernels
identical. Static3BAR.SYNCsites unchanged; loop skips final64levelCTAbarrier/store,
reconstructs parent inverse onboth leafhalves. Exactcommunication tradeoff possible
but not qualifying. Do not unchangedredraw. SeeITER40-BOTTOM-FUSION-REVIEW.md.
Adjacent-lane bottompermutation+shuffle to eliminate replicatedMUL is a distinct
untestedstructural lever; no evidentiary performance claim.

## Iter41 adjacent sibling shuffle

QSB_TREE_BOTTOM_SHFL ownershippermutation+evenlaneparentMUL+broadcast exact
N24PASS11762hits;409.534027->403.253036(-1.533692%)production screen. Stop,
noqualification,nosubmission,noredraw. Native14776inst128regs24KiB16Bstack
12Bspillstores8Bloads;local14800instzero stack/spills. SHFL+8both;other5kernels
identical. Offnativebyteexact. Fullsource/SASS/benchhitsevidence archived.
FrontlocalityandQ_MIXlogicalassignmentchange,sochangeisnotjusttreeinstruction
saving; nofullold/newhitsetequivalenceorcausalperformanceattributionclaimed.

Iter42QSB_TREE_LEAF_SHFL:storageonlypermutationpreservesfrontownershipbutmoves
prodAparkingtoupperdeadproductrowstoavoidoverwriterace. N24PASS416.153->401.244
Mps(-3.583%)production,11835verifiedhits. Nativespillfreeunlikeiter41;stillnot
positive. Native14520->14672instructions,local14576->14728,128regs24KiBshared.
Fiveotherkernelsidentical,offnativebyteidentical. Stopperpreregisterednegative
screen,nosubmission. Do not replaybottom-tree shuffle/fusion fornoise;changeaxis.
Associationwithspeculativeshortcarryisdifferent,notexactcoveragepreservation.


Iter43QSB_TREE_STATIC_N (rolled CTA128 constexprextent):exactN24PASS11489hits,
398.950634->396.208785M/s(-0.687265%)production screen;stopperpreregisterednegative.
Noqualification/submission/noiserescue. Native14520->14512instspillfree;local
14576->14600,8Bstack/one64bitlocalsave-restore;PTXAS0spillstores/loads(iter44correction). Same128regs24KiBshared/fiveotherkernels.
BRA-2butS2Runchanged. Offcarrierbyteexact. Do not repeatfornoise;constexpr
address-only or spillintervalrepair is a different unverified candidate.


Iter44primaryauditcorrectsiter43:localSTL/LDLareinside2calledfrontbody,
notrolledtree. Sm86front+22of+24instructions;nativefront+4despitetotal-8.
Do not infer tree-local spill or causal slowdown. Iter34 early gate/all-four
aggregates are nonbinding;alternating1/2/4incrementality-1.441331%FAIL.
Iter35+6.389639%leaderbut-1.482465%productionFAIL. Nounchangednoise-reruns.
Auditreviewlab/ITER44-EVIDENCE-REVIEW.md;correct-seedexistingverifier5723PASS.

Iter45QSB_TREE_CONST_ADDRkeepsdynamicloopboundsbutderivesconstantlayout
addressesandremovesoffsetrecurrence. ExistingN24exactscreen11787hitsPASS,
410.543609->402.807299M/s(-1.884406%):stop,noqualification/noiserescue/submission.
Native-16instructions/local+16,localregs127,zero stack/spillsbotharchs;
fiveotherkernelsidentical,offnative/localbyteexact. Onepairnotstatisticalproof.
Thisrepairselocalstackbutnotthroughput;do not keep exploring unchangedtree
addressvariantsfornoise. Reviewlab/ITER45-CONST-ADDR-REVIEW.mdandfindingsjson.

- Iter46 QSB_PW_HI_APPROX: high-half-only D6/D13 parity products with bounded
  carry omission and stricter guard/exact original fallback. Not split ILP.
  PASS11673hits,404.959->401.606M/s,-0.828% production screen. Both128regs24KiBshared
  spillfree; native+104inst/local+112inst because old narrow remains cold fallback.
  Keepoff; no noise rescue or leader qualification. Evidence ITER46-HIGH-HALF-REVIEW.

## Iter47 exact subtractive-Karatsuba at dynamic tree seam

QSB_TREE_KARATSUBA defaultOFF. Raw48vs64 limb products; whole digest -176
IMAD.WIDE but +728sm89/+744sm86 instructions and new spills. Exact benchmark
PASS11997hits, production418.841294->408.995789M/s(-2.350653%)one120s pair.
Stop negativeincrementality; noleader/norescue/nosubmit. Other5kernels unchanged;
OFFnative/localcubins byteexact. Existing unscaled tree_audit output identical
control/candidate but bothexit1(speculativeedgefailures); no canonicalPASSclaim.
Do not repeat dynamic-tree Karatsuba. Constant-operand specialization is distinct
and unmeasured, needs a materially cheaper emitted cross-term schedule first.

## Iter47b exact packed segmented inverse carry

QSB_INVERSE_PACK_CARRY defaultOFF. Four-row ballot arithmetic exact, clears
rowboundary prop bits in packedadd and recovers cout=gen7|(carry7&prop7).
No omittedcarry/cap/fallback. Pre-existing unscaled audit fulltextidenticalcontrol,
both exit1 inherited speculativeedgefailures not overallPASS. Native14520/local14576
unchanged; -2SHF+2LOP3,128regs24KiBzero stack/spills; other5kernelsidentical.
Disabled native/local cubins byteexact. Actual benchmarkPASS11209hits:
391.507030->382.114284M/s(-2.399126%)one120sproductionpair. Stop noleader/norescue/
nosubmit. Existing curveinvariantfinish and problemISO_INVU(nonunit) kill two
consult proposals by sourceinspection; noGPUwork for those. ReviewITER47B-PACKED-CARRY.


## Iter47c startup high-ladder prefix reuse

QSB_GT_PREFIX_CACHE defaultOFF. Repeated exactXYZprefix cachedper16recordbatch;
127103149prefixadds avoided by exhaustiveCPUworkcount. No SHA/digest changes:
otherfivekernels instructionidentical; offnative/local cubinsbyteexact. Fullwindow
N24PASS11412hits396.397219->393.332674(-0.773099521%)oneproductionpair. Stop
negative screen,no noise-redraw/leaderqualification/submission. CountisnotGPU
startup timing; isolatedtabletiming missing, so do not claimthatactualstartup
speedupwasmeasured. Builder+144inst118regs2272Bstackzero spills. ReviewITER47C.


## Iter48 isolated startup timing closes iter47c lead
Production measured table buckets140.407537ms vs prefixcache133.196337ms;
9.089989ms builderbucket saving,7.211200ms totalsaving. Full repaired9.8GB
tables SHA256identical; existingbenchmark exactPASS5182hits. One localpair
notnative/repeatabilityproof; hashing inside window invalidates diagnosticscores
asqualification. Deleting measured tablecost=.011700628%1200sbudget; far below
4%gate. No more one-time point arithmetic optimization without new evidence.
Broaderstartup excluded: don't killallocation/contextcost axis from this timing.
Next repeated epochs/first-state/digest work; no submission. ReviewITER48.
