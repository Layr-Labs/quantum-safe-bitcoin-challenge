# Subset notebook — handoff after iteration45

Standing orders: editable candidates/subset only; GPU runs serialized by flock;
>=3 alternating actual-promoted-leader/candidate pairs, >=4% local gain, exact
verification and positive production incrementality before submission. Winning
qualified candidates must be submitted immediately with required attribution.
Board currently faf5422a/efef868,753.571538M/s; +1%target761.10725338M/s.

## Iter45 constant tree addresses with dynamic bounds — negative exact screen

QSB_TREE_CONST_ADDR defaultoff. Preserves production wave-top, dynamic n/count
loop extents, operands, lane masks, candidate ownership, barriers and arena.
Derives rolled offset=256-2*count, wave root224, inverse subtraction128 and
final leafhalf64. Launchguard requires pairedTRIM1CTA128, rejects incompatible
layouts/parking/fusion/staticextent. Initialguarderroneouslyexcludedwave-top1;
correctedbeforeGPUwork,failedlogsretained. Logicalstate/addressreviewin
lab/ITER45-CONST-ADDR-REVIEW.md. Existingbenchmark.sh viaiter34_ab120seachN24,
seed1789110211,flock: production410.543609M/s5948hitsPASS->402.8072995839PASS,
-1.884406%;11787exacthits. BothPoisson/counteradvisoriesretained. Nonpositive
preregisteredscreenstop,noactualleaderqualification,noiserescue,nosubmission.
Native14520->14504instructions128regs;matchedlocal14576->14592127regs;
both24KiBshared0stack/spills;fiveotherkernelsidentical. BothIADD3-2/IMAD.IADD-7,
localBRA+1/nativeBRAunchanged;S2R/BAR/SHFLsame. Disablednativeandlocalbyteexact
qualifiedpriorcubin. LocalcensushadtoincludeLOCAL_SM86knob;wronggeometry
diagnosticretained,measuredwrapperwasalreadycorrect. Eliminatesiter43local
stackwithoutconstexprloopbounds,butdoesnotproveperformancecausality. No
unchangedspeedreruns. Newleadmustleaveaddressingaxisforrealworkelimination.
Evidence:lab/iter45-findings.json,losslesscode/screenhistoryarchiveandreceipt.
RootNOTEBOOKuntouchedpereditablemanifest;thisnotebookiscoldhandoffsource.
Finalretention85members279070720->3875308B,allcurrent/priorbytesPASS; package
7934769Bbeforefinaltext. All20oldtarcontainersbyteexactrestorable(ordinary9or
9EXTREME)withiter45-restore-history.py. Firstrepackoverbudgetfixedlosslessly.


## Iter43 fixed extent for rolled inversion (distinct indexing experiment)

DefaultoffQSB_TREE_STATIC_N sets constexpr n=QSB_SE_BLOCK128 in original rolled
up/down tree, no unrolling/permutation/arithmetic association/barrier changes.
Supported launch contracts reviewed: paired shortepoch launches128;ZLAB_TRIM1
rejects unsupported legacyBLKSZ256route. Finalguard requiresTRIM1, paired scalar
ZLAB_TREE2/CTA128, no bottomshuffle/fusion. Firstbuild guard failed before shared
macrodefinition, corrected includeordering; noGPUwork from failedbuild.
N24existingbenchmark.sh120sproduction/staticpair,seed1789110211,PASS11489hits:
398.950634M/s5766hits->396.208785M/s5723hits,-0.687265%. Preregisterednegative
screen:stop,noactualleaderqualification,nosubmission,nonoiserescue. Onepairnot
significantproofsmallregression. Productionselector/nativecarrier unchanged.
Native14520->14512instructions,zero stack/spills128regs24KiBshared;local14576->
14600,8Bstack64bitlocalsave/restore(PTXAS0spillstores/loads;iter44correction). BRA-2both,S2Runchanged,BAR3/SHFL38/sharedtraffic
unchanged;fiveotherkernelsidentical. Disablednativebyteexacta724399a...;
finalpreprocessingguardsame measuredcubinidentity PASSnativeoff/on+localsm86.
Optionalreviewerformationreturnednoanswers;logicalreviewours,CPUverifierexact.
Reviewlab/ITER43-STATIC-TREE-REVIEW.md,iter43-findings.json. Losslesscurrent plus
prioriter40/42 jointrepack PASS154members,74967040->976096bytes;allmembersequal.
Finalretainedverifier/evidenceauditPASS;package<8MiB(~51KiBheadroom).
iter39prior-recordsmanifest losslesslyxzcompressed,roundtripPASS.
RootNOTEBOOKnoteditedduetomanifestonly;thiseditable notebookishandoffsource.
Nextunverifiedlead:constantaddressonly(loopboundsdynamic),orlocalspillliveinterval.


## Iter41 adjacent-lane bottom shuffle (new structural follow-up)

Defaultoff QSB_TREE_BOTTOM_SHFL permutescandidateownership p(t)=(t>>1)|((t&1)*64)
forCTA128,storesproductsatlogicalcandidatecolumn,keepsparkedfrontstatephysical.
Originalleafsiblingsnowadjacent;evenlanereconstructscommoninverse,8SHFL.IDX
publish4x64bitwords. LastdynamicCTAbarrierremovedwithoutiter40duplicatedMUL.
ExactN24screenPASS5942+5820hits:409.534027->403.253036M/s(-1.533692%).
Negativepreregisteredscreen:noleaderqualification,nosubmission,nonoiserescue.
Singlepairnotstatisticalproofof1.53%slowdown. BotharmsPoissonadvisoriesretained.
Native14520->14776inst,128regs24KiB16Bstack/12Bstores/8Bloads;local14576->14800,
128regs24KiB0stack0spill. Other5kernelsidentical. SHFL38->46bothroutes;BAR.SYNC
3->3staticrolledloop. Disablednativebyteexacta724399a...; productioncarrierunchanged.
CompilerfirstguardfailedbeforeQSB_PAIR_SHAREDdefined;guardmovedafterinclude.
Controlbinarylinknamewrongpreflight,noGPUrun;fixedtosha65bc01e3...retainedcontrol.
DisassemblyneedsCUDA12.8binonPATH;failedattemptsretained,neverGPUnoisererun.
Reviewerformationreturnednoanswers,noexternalreviewclaimed. See
lab/ITER41-BOTTOM-SHUFFLE-REVIEW.md,iter41-findings.json,losslessiter41-evidence.
PermutationchangesfrontwindowlocalityandlogicalcandidateQ_MIXassignment:
CPUverifierprovesreportedhits,notfullold/newbitexacthitset. TreeMULassociation
preservedconditionalonleaves. Nextnecessaryactiontrace/retirepermutationindex
lifetime/nativefrontplumbingspills or preservefrontlocalitywhilechangingonlytree.

## Iter40 last internal tree publication/barrier fusion

Defaultoff QSB_TREE_BOTTOM_FUSE, last downlevel inverse reconstructed in registers.
Exact N24screen5872+5906hitsPASS406.588457->408.309257(+0.423229%). Qualified9run
allPASS:leader387.810532,bottom395.549748,production394.635123M/s. +1.995618%vs
leader,+0.231765%incrementality; required4%gateFAIL,no submission/no noise redraw.
Candidate17198hits,leader16748,production17174 inqualification,51120/51120PASS
there;total62898/62898including screen. Native14520->14632inst/local14576->14696;
128regs24KiB0stack0spill both;other5kernelsidentical. One dynamic lastCTAbarrier
removed although3staticBAR.SYNCsites unchanged (rolledloop); replicatedMUL tradeoff.
Offnative rebuilt byteidentical; production selector/carrierunchanged.
Evidence lab/ITER40-BOTTOM-FUSION-REVIEW.md,iter40-findings.json,finalauditjson,
lossless iter40-benchmark-evidence and emitted-history archives. Olditer37/38/39
emitted tarpayloads preserved together; iter40-restore-code.py restores original
containers byteexact before oldaudit scripts. No historydiscarded.
Qualification jobexit2 postloop:edited executing shellscript shiftedread offsets;
all9GPUbenchmarksPASS,lastscore/artifactrecovered checked,no rerun. Fixedbashsyntax.
Nevereditexecuting script. Rootresults hittexts are cumulative, not scoring inputs;
retain harness runJSON hitset instead. Actualboard unchanged753.571538.

## Iter39 common A/B shared publication

Mode1 six parameters: N24 exactPASS10552hits,365.043157->362.191191M/s(-0.781268%).
Mode2 single address/tag: exactPASS11645hits,402.934989->399.475950(-0.858461%).
No leader qualification, no submission, both off. One-pair screens are decision
gates, not statistical proof of subpercent slowdown. Mode2 arms both have harness
Poisson/candidate-count advisory; exact verification PASS, scores/counters distinct.
Total22197/22197hitsPASS. Production selector/carrier same, final offnativebyteidentical.
Both common ABI returns72B (production136B), onefieldbody/twocalls. Native mode1
14520->14632instructions,32Bstack/44Bstores/8Bloads. Mode2 repairs that:14552inst,
zero stack/spill/localmemory sm89. Localmode2 14656inst,24Bstack/24Bstore/16Bload.
All128regs24KiB,other5kernelsinstructionidentical. Correct sharedarena reuse is
possible but no gain qualified. See lab/ITER39-COMMON-PUBLICATION-REVIEW.md.

## Lossless history

Earlier notebook/deadends exact originals are lab/iter39-historical-notebooks.tar.xz;
old lab records/procedures are iter39-prior-records/procedures archives; old
submission notes are iter39-legacy-notes.tar.xz. Each has verified memberhashes.
Restore old source/log pathnames before invoking old audit/reproduction scripts.
New iter39 scripts and existing iter34_ab.sh remain loose and executable by bash.
No production dependency was removed. Reviewfiles from iterations35..38 are in
priorrecords archive, manifest lists original paths. Full loop/hypothesis history
has not been summarized away.

## Next necessary action

Find a materially different mechanism that removes work/communication; do not
repeat unchanged A-only, words-only or either common publication for noise.
Bottom fused reconstruction is nonqualifying. New adjacent-lane bottom-tree
permutation could share inverses with warp shuffles instead of replicated MUL;
implemented in iter41 above; exactPASSnegative screen, do not unchangedredraw. Preserve operand association/identity masking.
Publication combined with outer relocation remains untested without positive
interaction evidence. Currentproduction is our qualified block128/denreloc/center2/
checkalias/tightcap/pack8fullcap stack,not automatic copying of leader rolledtail.

Final restoration audit: all881tracked deletions correspond to hash-exact
archive members (iter39-restoration-audit.json). Final board refresh unchanged.
Package byte count and emitted/source audits in iter39-final-audit.json.

Iter41retention: iter40historynowinsideiter41-evidence-history.tar.xz; use
iter41-restore-history.py to restore originalcontainer beforeoldaudits.
iter40-restore-code.py reads nestedtar transparently. Prioriter34/38bench
archivesnormalizedrawgzipwithheaders/trailers/skeleton preserved; use
iter41-unpack-gzip-history.py --restore to restore byteexactoriginalcontainers.
Receiptsretainmemberlengths/hashesand originalcontainerhashes. Noevidence
discardedfor8MiBbudget.

Finaliter41retainedauditPASS:11762exacthits, measuredsource/offcarrieridentity,
allcurrent/priorcode/memberhashes andbyteexactbenchmarkcontainerrestoration.
Package7685876Bbeforefinaltextappend(<8388608);>700kBheadroom. GPUjobsfinished,
noexperimentenabled,noqualifiedwinnerheld. Seeiter41-final-audit.json.

## Iter42 — leaf-only tree permutation, negative verified screen

Effortxhigh. Boardactualfaf5422a/efef868753571538. Iter41 changed candidateowner;
iter42insteadkeepsfront/candidate/Q_MIX/hitownershipuntouchedandpermutesonlytree
leafstorage,p(t)=(t>>1)|((t&1)*64). Neighborlanes sharebottominversevia8native32bit
shuffles. prodAparkingmustmoveintodeadupperproductcolumns128..255: otherwise
permutedleafstorecanclobberanotherwarp'snot-yetreloadedprodA. InitialCTAbarrier
separatesreloadsfrominternalproductwrites;allocationunchanged. Defaultofftls1.

Matchedsm86N24screen viaexistingiter34_ab/benchmark.sh,120seach,seed1789110211,
GPUflock. Production416.153011Mps6019hitsPASS;leaf401.243768Mps5816hitsPASS,
-3.5826349%.11835independentverifiedhits. Preregisterednegativescreenstop;no
leaderqualification,norescueruns,nosubmission. Singlepairnotasignificanceclaim.

Nativesm89spillregressionfromiter41iseliminated:enabled128regs24KiBsharedzero
stack/spills,localsm86same. Native14520->14672instructions;local14576->14728.
Allfiveotherkernelsinstructionidentical,botharchs. StaticBARsites3->3(dynamically
skipslastdownleveliteration);SHFL38->46. Disablednativebyteidenticaltoqualified
productiona724399a04db515f8bebd836b1af866e6e7a1b778a98ce73a384c6f7704de147.
Treeassociationchangesunderexistingspeculativeshortcarry;hitPASSisnotproof
ofexactcandidatecoverage. Revieweredgecounterexamplesnotindependentlytested.

Reviewandreceipts:lab/ITER42-LEAF-SHUFFLE-REVIEW.md,iter42-findings.json,
iter42-evidence.tar.xzpluslosslessmember/binaryhashmanifest. Pre-existingbenchmark
only;unbuiltinventeddiagnosticremovedperoperatorinstruction. BuildstampandCUDA
disassemblyPATHbootstrapfailuresrecorded;correctedbeforeactualmeasurement.
Followup:leavebottom-tree/ABIpublicationdirection;selectmateriallydistinctwork
eliminationormemorypressurelevernext. Selectorandembeddedcarrieruntouched.


## Iter44 mandatory 15-iteration audit — PASS, no new speed run

Reviewlab/ITER44-EVIDENCE-REVIEW.md and losslessiter44-evidence-review.json.xz.
Actualfaf5422a/efef868753571538; literal+1%761107253.38,delta7535715.38;
integer>=761107254.64publicsourcefilesmatch;previousleaderdeviceidentical.
Allactive37..43SASS/resourcesrecount,other5kernelsidentical,128regs24KiB.
Iter34earlygatespassedbutbindingalternating1/2/4productionincrementality
-1.441331%;iter35outlined+6.389639%leaderbut-1.482465%production;iter40
+1.995618%leader/+0.231765%production<4%local. Noeligiblewinner/submission.
Screens30..43reconciledagainstprimaryscores/logs/runartifacts;negativeorflat
screensnotredrawnfornoise,onepairnotgeneralregressionproof.
NEWiter43accountingcorrection:PTXAS8Bstack,0spillstores/loads (not8Bspills);
SASSoneSTL.64/LDL.LU.64,bothinside2calledfrontbody0x2b1b0..0x38e60,
notinthetreeloop. Sm86+24total=-2prefix,+22front,+4tail;sm89-8=-9prefix,
+4front,-3tail. Unchangedfrontsourceallocationrescheduledfromcallerchange;
no causalperformanceclaim. Nextunverifiedleadisolateconstantaddresseswhile
keepingdynamicloopbounds/frontABI,notblindtree-localspillrepair.
Existingharness/verify.pycorrectretainedseed1789110211,N24:5723/5723,
failed0PASS. Initialwrongseed0reverifyREJECTandteeexit0retained;corrected
QSB_PROBLEM_DIR+pipefailnoGPU/speedrerun. Bothlogsretainedinlab.
Proceduremanifest36923->10964Blosslessjson.xz,hash/memberauditPASS;restore
old.jsonpathnamebeforearchivedoldprocedures. Noevidencediscarded.
Selector/carrierunchanged,allvariantsdefaultoff. Rootnotebookuntouchedbecause
manifesteditablepathonly. Finalpackagebytesiniter44-package-receipt.json.

## Iteration46 — high-half-only parity carry approximation (off, exact PASS)

New QSB_PW_HI_APPROX drops nine wide low halves/carry chains, not the prior
accumulator-ILP or bit32 rearrangements. Bounded omitted middle carry<=6, top
carry<=1; stricter M/Q guards preserve original fast-path bits. Rejection runs
unchanged original narrow/27product/speculative fallback. Both128regs24KiBshared
zero digest stack/spills. sm89 14520->14624, sm86 14576->14688; five other kernels
instructionidentical. Both disabled cubins byteexact to iter45. Static growth is
cold fallback, not evidence of hot-path performance. One preregistered120spair
N24seed1789110211, serialGPUflock: production404.959289M/5861hits ->
401.606313M/5812hits **-0.82797854%**, bothPASS11673totalhits. Stop nonpositive:
no noise rescue, no leader qualification, no submission. Count/Poissonadvisory
retained; hit verification not full coverage proof. Actual board stillfaf5422a/
efef868753.571538M. Missing tools/path and absentcontrol blocked earlier jobs
before timings; regeneratedcontrolonce (hosthash differs, devicehashbyteexact).
Full review lab/ITER46-HIGH-HALF-REVIEW.md; JSONiter46-findings.json. Nativecarrier
untouched. Next: do not rerun HI approximation as is; target a distinct savings
in the SHA constant-block schedule or derive a narrower proven window, with cold
fallback kept source-identical and a preregistered production screen.

Iter46 retention: standalone evidence exceeded8MiB, joint cross-history with
scoped benchmark+top3board (unrelated1310submission export outsidepackage, hash
receipt retained) now~8.061MB. ALL old85members and current measured binaries,
SASS/hitlists/scores/source preservedbyteexact; rawtarrestore/audit scripts.
Postscreen only invalid-configuration guards moved after knobdefaultdefinitions;
validbuild tokensunchanged, no timings repeated. Region0x1e6c0-firstBRA native
interleaved finish/window42->54inst diagnosticnotisolatedhotcount.
## Iteration 47 — exact tree-product Karatsuba, negative production screen

Read standing orders and board before experiment; actual leader faf5422a,
753571538, efef868 (previous d7c57dd4 745663804, third 4cc9d2d8 736585478).
New arithmetic direction: QSB_TREE_KARATSUBA=1 replaces only the speculative
block-tree product schedule with subtractive Karatsuba. Full 512-bit reconstruction,
unchanged short-carry reducer; 48 vs64 raw limb products, no rejection guards.
Generator and new helper retained, default OFF; optional carrier knob empty OFF.

Pre-existing tree_audit initially exposed absent ISO_INVU startup. Unscaled
candidate/control runs have BYTE-IDENTICAL complete output logs (both exit1;
existing speculative edge failures, NOT overall canonical PASS). Canonical helper
98304 exact checks is unchanged, distributed roots8192 exact, zero status errors.
No universal product-oracle or hit-coverage proof claimed.

Native sm89 digest14520->15248 (+728), IMAD.WIDE3644->3468(-176), IADD3+609;
sm86 14576->15320(+744), IMAD.WIDE-176,IADD3+610. Native8Bstack8Bstores8Bloads;
local8Bstack12Bstores8Bloads. Both128regs24KiB. Other5kernels instruction-identical.
OFF native/local cubins BYTE-IDENTICAL to iter46 production; carrier unchanged.

One preregistered120s N24 production screen through existing iter34_ab.sh:
A418.841294 M/s6077hits, B408.995789 M/s5920hits, -2.350653%, both exact
benchmark PASS,11997hits total. No leader qualification, no noise rescue,
no submission. This does not justify declaring constant-operand Karatsuba dead,
but repeating the dynamic tree schedule is unsupported by emitted and measured
results. Tool package path failures fixed without any benchmark restart.

See lab/ITER47-KARATSUBA-REVIEW.md, iter47-findings.json and lossless history.
Root notebook left unchanged under manifest editable-path restriction.

## Iter47b exact packed segmented inverse carry

QSB_INVERSE_PACK_CARRY defaultOFF. Four-row ballot arithmetic exact, clears
rowboundary prop bits in packedadd and recovers cout=gen7|(carry7&prop7).
No omittedcarry/cap/fallback. Pre-existing unscaled audit fulltextidenticalcontrol,
both exit1 inherited speculativeedgefailures not overallPASS. Native14520/local14576
unchanged; -2SHF+2LOP3,128regs24KiBzero stack/spills; other5kernelsidentical.
Disabled native/local cubins byteexact. Actual benchmarkPASS11209hits:
391.507030->382.114284M/s(-2.399126%)one120sproductionpair. Stop noleader/norescue/
nosubmit. Existing curveinvariantfinish and problemISO_INVU(nonunit) kill two
consult proposals by sourceinspection; noGPUwork for those. ReviewITER47B-PACKED-CARRY.


## Iter47c: startup repeated high-ladder prefix reuse (off)

Distinctwork lever: QSB_GT_PREFIX_CACHE caches theexact homogeneous Sp+Hp prefix
per16record32stride tablebuild batch, keyedby(ch,hi,h2). FullXYZsaved;lowaddition,
inversevalidation/retry,tablehealing/spotcheck andcandidatepaths untouched.
Exhaustive CPU153175181record census:135576717originalprefixadds ->8473568misses,
127103149avoidedadds(9M+2S each). This is workcount, not anisolated startup timing.
Nativebuilder5848->5992/local5832->5976;118regs2272Bstackzeros spills. Allfiveother
kernels emittedidentical: digest14520/14576. Disablednative/local byteexact.
One existingiter34_ab.sh120sN24screen PASS11412combinedhits: production396.397219
5722hits ->393.3326745690hits(-0.773099521%). No leaderqualification,norescue,
nosubmission. Boardfaf5422a753571538. No repeat ofprevious47b: exact matchedcontrol
restored fromitsarchive; distinctly changedstartupkernelcandidate measuredonce.
Review lab/ITER47C-GTABLE-PREFIX-REVIEW.md and iter47c-findings.json; source/SASS/
cubins/executables/screenhits/runJSON hashretained in jointarchive. Futurestartup
lever needsisolatedtabletiming beforefullwindow; countofremovedworknotpromiseofgain.
Rootnotebookunchanged under stronger editablepathonlyrestriction.

Packaging47c: losslessappendexceeded8MiB, source-onlydeterministiclayout saved
312891B withoutlosingoriginalsource/SASS/hits. Complete preprocessedTU token
identityPASSnative887057/local882184; disablednative/localcubinsbyteidentical.
Currentfinalaudit checksallhistorical/currentmemberhashes+layoutsource+cap.
NoGPUperformance retry forpackaging; earlieraudit scripts historicalsourceonly.


## Iter48 isolated table phases and complete repaired table identity
QSB_GT_PHASE_AUDIT defaultoff: production140.407537ms, cache133.196337ms;
kernel bucket108.199511->99.109522ms. Complete9803211584B repaired tables same
SHA256 c73580daaee00907a3fb13a0d3e4ae5497d6c19975c5df4663008765991f4f6f.
Existingbenchmark N24 seed1789110211 exactPASS2598+2584=5182hits. Firstpair
stdoutcapture absent because gpu_wrap discards kerneloutput; audit-only results
receipt added, failed shell unbounda corrected beforeGPU. No noise-rescue.
Hashinsidewindow so diagnostic356.871201/353.332542M/s notqualification.
Entire measuredtablecost=.011700628%1200s budget; cache saving=.000600933%.
One localpair notrepeatability/nativeproof; broaderstartup notmeasured. Default
productionunchanged; noqualifiedcandidate,nosubmission. Redirect repeatedcritical
path. Full details lab/ITER48-GTABLE-PHASE-REVIEW.md; finalretentionaudit pending.

Iter48 caveat: timedactual3090/localknobs use9.8GB GLV12; native4090 uses
22.7GB GLV11/P18, so no directnative budgetbound claimed. NativeGPU profiling
still unavailable. Preprocessed fulltokenidentity887057(native)/882603(audit)
PASS; disabled native/local cubinsha a724399a/95598e44 byteexact. Artifact
caprepack pending, lossless source deltas remove duplicatedtree text.
