# Subset evidence archive routing — iteration 47

Active source and wrappers remain loose. Current findings are in
`iter47-findings.json`, `ITER47-KARATSUBA-REVIEW.md`, and `iter47-final-audit.json`.

`iter47-joint-history.tar.xz` contains every prior retained payload plus the
measured iteration47 evidence, independently hash-manifested:

- `iter45-lossless-history.tar.xz.rawtar` + its `.manifest.json` retain all older
  build/source/benchmark payloads already audited in iterations45/46.
- `iter46-evidence.tar.xz.rawtar` + its `.manifest.json` retain the high-half trial.
- `iter47-evidence.rawtar` + `iter47-evidence.manifest.json` retain actual screen
  scores/run JSON/hits/full logs, builds, SASS/cubins, measured executables,
  source closure and relevant public board trees/notes.
- `historical-loose-lab.rawtar` + `historical-loose-lab.manifest.json` retain 199
  old lab documentation/scripts/manifests previously loose. These have been
  folded losslessly because the current evidence increase would exceed the
  8MiB cap. Nothing is discarded to gain throughput or space.

To recover a referenced historical lab file, open the outer archive with
Python's `tarfile`, extract the named rawtar member into memory or a development
scratch directory, then open that rawtar with `tarfile` and retrieve its member.
The historical loose-lab members are named relative to this directory. For
example, `iter46-final-audit.py` remains available there with identical bytes.
Existing notebook references to those paths should be routed through this
archive; they are historical evidence, not current entry points.

The exact final commands remain directly runnable as:
`python3 candidates/subset/lab/iter47-final-audit.py` (evidence integrity; no GPU)
and the benchmark entry points described in the review (GPU flock required).
The full unrelated board export is externally retained and hash-scoped, not
claimed reconstructible from the package. Only benchmark/top promoted entries
and relevant public source trees/notes are packaged.

Measured candidate and control executables are retained in the archive under
`measured/`; their loose copies/build stamps are removed after hashing to meet
the cap. They are not ranked executables. The production carrier remains
unchanged; `QSB_TREE_KARATSUBA` is disabled by default.

Cap correction details: the initial joint archive, folded loose-history archive,
and lc0/lp0/pb0 compression trial projected packages above8MiB. The lc0 trial
made the archive larger(5590192->5631700B), so it was discarded. The final
format losslessly normalizes only embedded base64 carrier arrays into their raw
cubin bytes and a JSON template/chunk-length list. `reconstruct` in
iter47_normalize_carriers.py recreates each carrier header byte-for-byte and each
original nested rawtar byte-for-byte; its own assertions checked all transforms.
The final audit reconstructs and checks every original nested member manifest.
Legacy unused tests/gpu_epochs/tree.cu.orig.gz is stored as raw source under
legacy/tree.cu.orig with exact gzip.compress(level9,mtime0) reconstruction and hash
in legacy/legacy-source-gzip.json. No referenced source or production cubin changed.

Iteration47b appends the exact packed-carry experiment. The current archive
retains the earlier .normalized rawtars and adds iter47b-evidence.rawtar.normalized
with its originalmembermanifest. Reconstruct using iter47_normalize_carriers.py,
then verify every original member. Run iter47b-final-audit.py for currentarchive.
The attempted SASSbinarycodec increasedarchive5400236->5959120B; discarded.
Codec scripts retained as evidence of rejected packaging, not currentformat.
To stayunder8MiB comments in tests/gpu_epochs/tree.cu were retired; complete
original measuredsource isarchived; leading attributionblock,newlines,string
literals and executabletokens arepreserved. Source compaction isdefined by
iter47b_source_codec.compact. Native/localdisabledcubins must be byteexact.
NoGPUbenchmark was repeated for packaging.


Iteration47c appends iter47c-evidence.rawtar.normalized with its member manifest.
Retains startup prefix-cache screen, complete measuredsourceclosure, compiler
logs, full SASS, nativecandidate+disabledcubins, measuredexecutables+stamps,
exactscore/runJSON/hitfiles, exhaustiveCPUworkcount and relevantleadernote.
Run iter47c-final-audit.py for the current archive and source. Earlier finalaudit
scripts are historical measuredsourcechecks; sourcechanged since those screens,
so earlier scripts are not currentworkspace acceptancecommands. They remain
retained as evidence, not silently rewritten to accept different source.
The full all-board export remains external and hash-scoped; selected promoted
entries and the currentleader publicnote are retained.

Currentsource uses iter47c_source_layout.py: whitespaceoutside literals/comments
compacted; nonattributioncomments inCPUheaderandfournamedhelpers archivedonly.
Allstrings,newlines andnoticespreserved. Complete measuredoriginalsource remains
in iter47c-evidence.rawtar.normalized; currentmap checkedbyiter47c-final-audit.py.
Fullnative/local preprocessedTUtokensidentical andoffcubinsbyteidentical receipts
in iter47c-package-identity.tar.xz. Layoutsaves312891B; nobenchmarkrerun.


Iteration48 appends `iter48-evidence.rawtar.normalized`,56members, including
original binaries/problem/hitartifacts/phase receipts and failed-capture pair.
`iter48-final-audit.py` is the current audit: all historical/current hashes,
5182 independently verified diagnostic hits, complete repairedtableidentity,
preprocessedtokens, disabled sm89/sm86 byteidentity and packagecap.
Prior phase audits target their original historical snapshots. Current source
has defaultoff hostaudit hook and literal-aware header commentcompaction;
originals archived. `iter48-target-before.tar.xz` retains exact prior target.
`iter48-package-identity.tar.xz` is package-only identity, not performance.
Historical normalized carrier payloads may be `.normalized.sass`: first decode
with `iter47b_sass_codec.reconstruct`, verify `.sass-original.json`, then decode
`iter47_normalize_carriers.reconstruct` to exact rawtar; manifests unchanged.
No evidence removed or speed/noise redraw. Findings/review named ITER48.
