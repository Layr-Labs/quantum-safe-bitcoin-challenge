# Evidence index current iteration48

Historical complete index in iter48-cold-lab.tar.xz cold-before/lab/EVIDENCE-INDEX.md.
Current integrity command: python3 -B candidates/subset/lab/iter48-final-audit.py
from repo root. Historical scripts/reviews/wrappers/tests retained losslessly in
cold capsule at original relative names; extraction restores them. Do not run
historical audits against new workspace; they target original snapshots.
Joint archive decoding: normalized.sass -> iter47b_sass_codec.reconstruct ->
original receipt hash -> iter47_normalize_carriers.reconstruct -> exact rawtar.
Manifests unchanged. Source deltas decode with iter48_source_delta.py using
current measured tree; all originals hashchecked. Actual phase binaries retained
exact; initial missingphase binaries overwritten, caveat preserved. See ITER48.
