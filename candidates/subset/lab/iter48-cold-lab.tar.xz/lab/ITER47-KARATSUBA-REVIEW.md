# Iteration 47 — exact subtractive-Karatsuba tree product: verified negative screen

Effort: xhigh

## Question and bounded intervention

The immediately preceding directions changed front ABI, tree ownership/addressing,
and guarded parity carry handling. This experiment instead changes the integer
multiplication algorithm. No retained notebook trial of subtractive Karatsuba was
found by the read-only source review. Three reviewers independently proposed the
same algebra at different dispatch seams. This iteration selects only the
speculative block-tree seam, `qsb_field_mul_tree` in `filter_tail_sc.cuh`; the fused
point-add body, standalone front field multipliers, squares, parity window,
publication path and exact replay remain unchanged.

`QSB_TREE_KARATSUBA` defaults to zero. With it enabled, the tree seam calls the new
`qsb_filter_mul_karatsuba`; with it disabled, it calls the previous helper. The
optional carrier fingerprint fragment is empty when disabled, so the existing
embedded production carrier remains valid. This does not promote the experiment
or regenerate the carrier with it on.

## Logical review of the generator and dispatch

The implementing code is `lab/iter47_generate.py`. It emits
`tree_karatsuba_sc.cuh`, extracting the original filter multiply's reduction and
output/fallback body rather than independently rewriting its speculative carry
policy. Split each input at H=2^128:

    a = aL + H*aH, b = bL + H*bH
    U = aL*bL, V = aH*bH
    D = abs(aH-aL)*abs(bH-bL)
    C = U + V - sign((aH-aL)*(bH-bL))*D
    a*b = U + H*C + H^2*V

The two unsigned differences are computed as 128-bit subtract chains, and their
borrow masks convert them to magnitudes. Difference magnitudes fit in 128 bits,
including the equal-halves/zero case. Equal borrow signs select subtraction of D;
opposite signs select addition. If either difference is zero, D is zero so either
sign selection gives the same C. U and V each use a 4x4 even/odd product schedule.
The third product uses the same schedule. This emits 48 `mul.wide.u32` terms
instead of 64 in the original 8x8 product.

The cross accumulator has NINE 32-bit words, because C can require 257 bits.
The final assembly adds C shifted by four words into the low U/high V image,
propagating through x15. The output interface is the original x0..x15. All reducer
source text from its register declaration onward, its compile-time carry cuts,
output assignments, and host fallback were copied verbatim by the generator.
Out[4] is still zero in the tree dispatch. Inputs are passed as asm operands before
outputs are stored, preserving both in-place alias modes. The experiment adds no
allocation, cleanup, barriers, rejection guard, dynamic bounds or empty-candidate
handling. The existing tree and exact verifier retain those responsibilities.

This is an exact integer-product algebra, not an approximation hypothesis. However,
no independent full-product oracle is claimed in this iteration: the existing
project audit does not directly expose all 512 Karatsuba product bits. Verification
below checks the existing tree audit's observable result counts and exact
publication of benchmark hits, not universal candidate coverage.

## Existing audit: setup diagnosis, not an invented test

The first pre-existing `tests/gpu_epochs/tree_audit.cu` run used production inverse
scaling. It returned 98304/98304 canonical multiplication matches, but all nonzero
inverse outputs failed. Inspection of `inverse_limbs.cuh` and `zinv32.cuh` showed
that the inverse initializes a row from QSB_ISO_INVU. Grinder startup populates that
constant; tree_audit does not. Its independent oracle expects an unscaled inverse.
Thus the meaningful comparison uses QSB_ISO_FUSED_ROOT_SCALE=0 and
QSB_ISO_ROOT_SCALE=0, on BOTH arms. No production source or test source was changed
for this diagnosis.

That audit's enabled and disabled arms produce byte-identical complete output
logs. Both still exit 1, because the existing speculative tree does not preserve
all of this canonical audit's edge inputs. Do not label the overall audit PASS.
The unchanged canonical multiply checks 98304 results. Distributed roots check
8192/8192 exact outputs; bounded-helper status/output errors are zero. Every
block-inverse summary, including its edge failures and congruent noncanonical
counts, is identical between the experiment and control. Those are summary-output
comparisons, not a hash of every result buffer or a direct Karatsuba oracle.

## Emitted code: multiplication saving overwhelmed by reconstruction

The full native digest census is 14520 -> 15248 instructions (+728), while its
IMAD.WIDE count falls 3644 -> 3468 (-176). IADD3 grows 2943 -> 3552 (+609).
The local sm86 digest is 14576 -> 15320 (+744), with the same -176 wide multiplies
and IADD3 2947 -> 3557 (+610). These are whole-function static counts, not hot
execution counts or causal timing attribution.

Both images retain 128 registers and 24576 bytes of shared memory. Native sm89
introduces an 8-byte stack frame, 8-byte spill stores and 8-byte spill loads. Local
sm86 introduces an 8-byte stack frame, 12-byte spill stores and 8-byte spill loads.
The native SASS has two local-memory instructions; local has six. This iteration
does not localize their source or claim they alone explain performance.
All five other device kernels remain instruction-identical on each architecture.
Disabled native/local cubins reproduce the preceding production cubins BYTE FOR
BYTE. The committed native carrier is unchanged, never replaced by the loser.

Development tooling failures are retained: cuobjdump is in a package's bin
subdirectory and requires nvdisasm's bin directory on PATH. Passing the executable
rather than directory as NVDISASM_PATH did not work here. The successful receipt
uses the real PATH. No GPU benchmark was restarted because of these tool errors.

## Preregistered benchmark screen and decision

Use the existing `lab/iter34_ab.sh` entry point with matched production wrapper
`n24L_iter37control.cu` versus `n24L_iter47karat.cu`, one 120-second A/B pair at
QSB_ZEROS_N=24, fixed problem seed 1789110211. All GPU invocations acquire the
shared GPU flock. Both builds use CUDA 12.8, sm86, QSB_LOCAL_SM86=1, and
QSB_CARRIER_BUILD=1, avoiding the ranked embedded sm89 image on this RTX3090.

| Arm | Verified candidates/s | Verified hits | Exact publication verifier |
|---|---:|---:|---|
| Current qualified production | 418841294 | 6077 | PASS |
| Tree subtractive-Karatsuba | 408995789 | 5920 | PASS |

The screen delta is -2.350653%. Total verified hits are 11997. Timing and hit-rate
uncertainty remain, and this pair is not a three-pair leader qualification. The
negative production incrementality is the stop gate: no noise-rescue repetitions,
no leader performance qualification, no submission. Self-reported throughput is
not substituted for the hit-derived score; the harness GPU label is static and
does not change that this local hardware is an RTX3090.

Before the experiment, the actual board leader was faf5422a at 753571538, source
efef868; d7c57dd4 at 745663804 and 4cc9d2d8 at 736585478 followed. Top-three notes
and public source were read; current and previous leaders' subset entry files are
identical. The full unrelated board export is not claimed reconstructible from
this package: scoped benchmark/top-three data, public-note text and relevant
public-tree source are retained with the experiment evidence.

## Reproduction and evidence boundary

Generate the helper with `python3 candidates/subset/lab/iter47_generate.py`.
Build the existing audit with nvcc -O3 -arch=sm_86, QSB_CARRIER_BUILD=1,
QSB_LOCAL_SM86=1, QSB_TREE_KARATSUBA=1, QSB_ZEROS_N=24, the two unscaled audit
switches above and -lcrypto; run under the GPU flock. Repeat only the audit build
with QSB_TREE_KARATSUBA=0 to obtain its disabled diagnostic control. Full commands,
compiler outputs, binaries, cubins, SASS, source closure, exact benchmark scores,
run JSON and hit files are retained losslessly in the history archive. Build
stamps identify the measured local binaries. Full raw command receipts also
record the initial setup/tool failures; those were not verifier successes.

The smaller number of wide multiplies is real, but not an issue-count win. The
initial dynamic sign handling/cross reconstruction is too expensive at this tree
seam. A future constant-operand specialization could remove one difference/sign
calculation, but it requires a materially narrower emitted schedule and its own
verification; this negative trial does not qualify that variant. Do not repeat
this global tree replacement or attempt random launch/clock noise rescue.

## Package finalization

Raw measured executables are archived rather than loose. Historic lab documents
and scripts are folded losslessly; EVIDENCE-INDEX.md supplies the reconstruction
route. Package pressure also required reversible base64-header normalization and
folding an unused legacy gzip source. All original source/cubin/benchmark/old
nested member hashes are checked by iter47-final-audit.py after reconstruction.
This packaging work is not another GPU trial or performance rescue. The existing
production carrier is unchanged. Source consumers need not know about evidence
normalization; it affects the evidence archive only.
