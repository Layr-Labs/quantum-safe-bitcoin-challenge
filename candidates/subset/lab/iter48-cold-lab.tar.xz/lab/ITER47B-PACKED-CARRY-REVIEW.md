# Iter47b — exact packed segmented inverse carry

Effort: xhigh

## Decision boundary

Dynamic-tree Karatsuba is spent at -2.35% production screen. Fresh deliberation
suggested a curve-invariant finish, but actual tree.cu and pair_shared.cuh already
implement it: lambda1*m2-c*(lambda1+m2)=-(xP+2*xR). A second proposed first-root
unit seed shortcut is inapplicable because the production R/S seed is the
problem-specific QSB_ISO_INVU. Neither was implemented or GPU-tested.

This test changes only the biased carry-lookahead of the warp root inverse.
No field product, carry bit, iteration, exceptional input, cap, fallback,
isomorphic scale or normalization is omitted. QSB_INVERSE_PACK_CARRY defaults0.
The optional carrier knob is empty OFF; the ranked production carrier is unchanged.

## Logical review

Four eight-limb rows share a warp. gen marks sum<lo; prop marks sum==2^32-1.
The predicates are mutually exclusive: an unsigned wrapping add cannot both
carry out and produce the maximum word. Current code independently extracts
and masks each ballot byte and computes carry=(prop+(gen<<1)) XOR prop.
The new code operates on all four bytes at once:

    p = prop & 0x7f7f7f7f
    carry = (((gen<<1)&0xfefefefe)+p) XOR p
    low = sum + ((carry>>lane)&1)
    cout = ((gen|(carry&prop))>>(lane|7))&1

prop bit7 is cleared solely inside the packed adder to stop a carry crossing into
an adjacent row. gen bit7 is excluded from the shifted seed for the same reason.
Each byte sum is <=255: gen and prop are disjoint, so adding twice-gen to the
low-seven-bit prop cannot create a byte spill. Within a byte, the ordinary
carry-lookahead addition propagates every carry into digits1..7. Row carry-out
is gen7 OR (carry_into7 AND prop7), recovered from the original unmasked ballot.
This is equivalent to the original carry bit8 even for an all-propagating row,
which still has no initial carry. An all-zero row generates no carry.

Only QSB_INVERSE_BIAS=1 is supported; invalid combination gets compile-time error.
The signed high accumulator retains its exact bias removal and row-local carryout.
The following >>30, termination ballot, output broadcast, signed canon and Fermat
fallback are untouched. Original root exceptional/zero handling and cap unchanged.

## Verification and emission

The pre-existing tree_audit.cu entry is built with QSB_ISO_FUSED_ROOT_SCALE=0 and
QSB_ISO_ROOT_SCALE=0 because its independent oracle expects an unscaled inverse.
Full candidate output is byte-identical to the retained unscaled production audit.
Both exit1 because of inherited speculative block inverse edge failures; no overall
canonical PASS is claimed. Distributed roots8192/8192 exact, bounded status0errors;
98304 unchanged canonical products exact. This establishes a matched diagnostic,
not universal new-path proof. Publication correctness is checked by benchmark.sh.

CUDA12.8 native sm89 digest instruction count stays14520; localsm86 stays14576.
Both128registers24KiBshared and zero stack/spill stores/spill loads. Two SHF removed
and two LOP3 added in each; other five kernels instruction-identical. This is not
yet a static instruction-count win. Avoid attributing performance to issue count.
Matched control was reconstructed byte-identically from retained iteration47
measured binary and build stamp, avoiding redundant build/GPU audit of control.

## Measured screen

One preregistered120s pair N24 using existing iter34_ab.sh. Both exact
publication verifiers PASS: control391.507030M/s5665hits, candidate382.114284M/s
5544hits. -2.399126% production screen,11209verifiedhits total. Stop negative
incrementality; no leader qualification/no noise rescue/no submission.
Disabled native and local cubins reproduce iteration47production byte-for-byte.
Performance is not inferred from the matched diagnostics or identical issue count.

Evidencepackaging retains completeoriginal SASS,cubin,measuredbinary,runJSON,
score/hitfiles,sourceclosure,compilerlogsand controlreport. Genericappendexceeded
capby~78KiB; SASSbinarycodec waslossless butmadecompressionworse andwasdiscarded.
Current archiveusespreviousreversiblecarrierformat. Commentonly tree source
compaction retainsnewlines andleading attributionblock; whole originalsource
archived. Native/localdisabledcubins recompiledbyteidentical beforeaccepting.
No performance claimor benchmarkrerun forpackaging.
