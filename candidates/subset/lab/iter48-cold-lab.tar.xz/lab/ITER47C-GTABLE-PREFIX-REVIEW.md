# Iter47c — exact repeated high-ladder prefix caching in startup

Effort: xhigh

A different dynamic-work lever after arithmetic carry/product screens failed.
The batchtablebuilder visits t0+32*j for j<16. Inside any high-ladder segment,
lo changes but (chunk,hi,h2) often does not. The builder originally reconstructs
Sp+Hp for each visited entry where hi!=0,h2!=0, before adding the distinct low
ladder point. QSB_GT_PREFIX_CACHE caches that exact homogeneous prefix only.
This is not a launch-size/inversionbatch sweep or omitted check.

## State and correctness review

Cache sentinel keys (-1,-1,-1) cannot match a valid first key. Every entry starts
from pz=1 and Sp; if h2 and hi are nonzero, mismatch executes exactly the existing
_PointAddSecp256k1(px,py,pz,Hx,Hy), saves all12 coordinate limbs andkeys. Match
restores those12limbs then executes the unchanged distinctlowaddition. The point
helper uses only pz[0..3], so zero pz[4] remains the same. A path with hi==0 or
h2==0 leaves cache untouched; a later entry can reuse it only after allthreekeys
match again. A chunkboundary,highboundary,orhigh2boundary necessarily causes a
miss. Slots emitted directly from L remain unaffected, invalidchunk continues,
partialbatchbreak and n==0return unchanged. The cached prefix itself is never
mutated by the later lowpointaddition or by batch normalization. Existing inverse
validation/retry,tablehealing and spotcheck remain active. No candidateenumeration,
SHA,hotpoint chain or publication path changes.

Each avoided prefix pointaddition removes9fieldM+2fieldS and fieldadds/subtracts
from startup only. This does not prove an endtoend gain: startup is one-time and
extra cache state/loadstores may offset the saving. Must measure the fullwindow.
QSB_GT_PREFIX_CACHE defaults0, optional carrierfingerprint empty0. No embedded
candidateimage installed.

## Emitted scope

Native/local digest and all kernels except kernel_build_gtable are instruction
identical to production. Digest remains native14520/local14576. Builder grows
5832->5976 localinstructions because cachingaddscontrol/loadstores. Exact compiler
logs,resources and SASS retained. Staticimage growth not the runtime loop cost.

## Verification plan

Use existing lab/iter34_ab.sh one120s N24productionpair with matched retained
control and n24L_iter47gtcache. SerialGPUflock as standingorders. Existinggrinder
startup tablecheck/heal and independentexactpublication verifier execute. Negative
productionincrementality stops beforeleader qualification; positive needs three
alternating actualleader pairs>=4% and positiveprod incremental subset before
submission. No noiserecovery repetitions.

## Concrete result

One preregistered production screen: A396.397219M/s5722hits; B393.332674M/s5690hits.
Both independentexactverifiers PASS,11412combinedhits; delta -0.77309952066%.
Stop: noleaderqualification, noise-rescue repetition or submission. Keep default0.
Nativebuilder5848->5992, local5832->5976. Cachebuilder118regs2272Bstackzero
spillstores/loads. Other five kernels emittedidentically. Freshdisablednative/local
cubinsbyteidentical topreviousproduction. Boardstillfaf5422a753571538.

The exhaustive153175181record CPUworkcount (iter47c_prefix_census.cpp) confirms
original135576717prefixadds become8473568misses;127103149avoidedprefixadds,
1143928341avoidedfieldmultiplies and254206298avoidedfieldsquares. Smallchunks
0-3have noeligibleprefix. Chunk4 avoids55036800adds;chunk5avoids72066349.
This census is not a cryptographic verifier; realpublication benchmark is above.
Eliminating93.75% of theseone-timeprefixadds did not improve the fullwindow
score. Do not infer speed from dynamic arithmetic count, nor infer a timedGPU
startup gain (no isolatedtabletimingrecorded). Even selfreportedcandidatecounts
remainnear41965/41970million; those aren't thescoredmetric. Tablehealing may
repairrare inverseissues asbefore; no claimtableexactidentity beyondpublication
and unchangedchecks. Futurestartupwork requiresisolatedtimingevidence first.


## Package-only layout

Archive append5702668B exceededcap; deterministiciter47c_source_layout preserves
strings,newlines andnotices, compressesoutsidewhitespace, retiresnonattribution
commentsinCPUheaderandfourspecifichelpers. Complete originalsarearchived. Saved
312891B. FullpreprocessedTUtokens identical(native887057/localcache882184tokens);
rebuilt disablednative/local cubinsbyteexact. Identityreceipt is
iter47c-package-identity.tar.xz. NoGPUbenchmark repeatedforpackaging. Currentaudit
iter47c-final-audit.py hashesallprior/currentmembers andchecks deterministicmap.
Earlierfinalaudits target theirhistoricalmeasuredsource, notcurrentworkspace.
