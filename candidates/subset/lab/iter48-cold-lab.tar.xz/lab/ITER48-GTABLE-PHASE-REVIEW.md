# Iteration48: close the missing table-startup measurement

Standing orders followed: current board inspected before work. Promoted leader
faf5422a/efef868 remains 753.571538M/s; +1% target 761.10725338M/s. Both its
public note/tree and prior d7c57dd4 note read. Qualified production left on;
all new diagnostics default off. Notebook lives within editable subset surface
because root NOTEBOOK is outside the manifest (same prior resolution).

## New evidence, not a repeat of the negative screen

Previous iter47c counted avoided additions but had no isolated startup timing.
QSB_GT_PHASE_AUDIT records four host wall-time buckets and hashes every repaired
record in bounded 16MiB chunks. No kernel instructions change. Hash starts after
production heal and 240 existing exact spot checks, before optional Y-offset.
Production failure aborts diagnostic instead of silently taking host fallback.
No difficulty/coverage/checks/enumeration modifications. It continues normal
mining, so the independent existing CPU verifier still checks every hit.

| seconds, local RTX3090 matched-sm86 route | production | prefix cache |
|---|---:|---:|
| CPU ladders, allocations and H2/H/L upload | .014043503 | .014234861 |
| builder launch/sync and ladder frees | .108199511 | .099109522 |
| heal setup/scan/repair/cleanup | .011216586 | .012771889 |
| spot gather and CPU checks | .006947937 | .007080065 |
| sum | **.140407537** | **.133196337** |

Same problem seed1789110211. Kernel bucket saving9.089989ms; total7.211200ms.
One pair, not a repeatability claim; GPUevent attribution and native timing not
measured. Hash overhead lies outside buckets but inside scoredwindow, so diagnostic
scores356.871201/353.332542M/s must NOT qualify throughput improvements. Every
hit exact PASS:2598/2598+2584/2584=5182. Both complete repaired9803211584-byte
images SHA256 c73580daaee00907a3fb13a0d3e4ae5497d6c19975c5df4663008765991f4f6f.
This closes table identity beyond the limited spotchecks, but is not proof of
raw builder equality, no repairs, or independent verification of all scalars.

Even deleting this entire measured140.408ms recovers .011700628% of a1200s
window; observed cache saving .000600933%. Excludes otherstartup/context/table
allocation: don't generalize to those. Startup table point-arithmetic lever
cannot plausibly supply +4% localgate on these observations. Redirect to the
repeated path; do not redraw negative iter47c.

## Exact entrypoints and failure evidence

Build wrappers n24L_iter48audit{0,1}.cu using nvcc -O3 -DQSB_ZEROS_N=24 -o
<matching binary> <wrapper> -lcrypto -lm. Both explicitly QSB_LOCAL_SM861,
QSB_CARRIER_BUILD1,QSB_GT_PHASE_AUDIT1; prefixcache0/1. Prebuild stamps are
harness-compatible. GPU work serialized flock /tmp/angel-gpu.lock.
Existing ./benchmark.sh subset using QSB_GRINDER=cmd:python3 harness/gpu_wrap.py
--src <wrapper>, QSB_ZEROS_N24,QSB_MODEfixed_time,QSB_SECONDS60,
QSB_MAX_REL_VARnone,QSB_PROBLEM_SEED1789110211. No new cryptographic test.

First pair exactPASS but stdout is discarded by gpu_wrap; absent phase data was
not called a timing result. Added results/gt_phase_audit.txt because bridge only
parses digest_hit*. Receipt-orchestration first failed unbound a BEFORE GPU;
fixed positional shell arg. Two capture runs then exactPASS and receipts copied.
These were missing-measurement diagnostics, not speed/noise-rescue reruns.
The existing harness internally time-bounds grinding; no builds wrapped in timeout.

Review checks: phase timestamps consumed only after successful build/heal/spot;
compileguard requires S3/heal/trim. Receipt failure is explicit. Hash reads full
range including finalpartialchunk, never mutates table. Temporary16MiB freed;
normalcleanup/mining remains. Existing unchecked alloc/OpenSSL errorpaths are
inherited, not claimed repaired. Phase buckets are broad walltime, not pureGPU.
Disabled images and package retention are audited separately, not performance
reruns. No qualification or submission; next necessary work is repeated-path
measurement and materially distinct work elimination.

## Package-only retention
The full diagnostic artifacts, problems, binaries, phase receipts and first
missing-output pair are appended losslessly to the joint archive. Non-attribution
comments in eight headers are compacted with the prior literal-aware codec;
leading notices and inline attribution markers remain. Full originals archived.
Complete native and enabled-audit preprocessed tokens match before/after; line
counts unchanged. Disabled sm89 and sm86 cubins byteexact both before/after
packaging and versus qualified prior cubins. This is source layout, not a speed
change, and no GPU rerun is used as packaging proof. Original payload hashes
remain reconstructible; finalaudit checks all hashes, actual hitscores and cap.

Hardware note: actual GPU RTX3090. Harness config declares RTX4090 in local
score JSON; that label is not hardware detection. Executables compiled by
harness-compatible default nvcc arch with QSB_LOCAL_SM86=1 matching production;
explicit sm86/sm89 cubins are identity checks, not these timed executions.

Historical evidence underwent reversible SASS encoding normalization:2184506
hex words stored as binary via prior codec. Saved161852B while retaining exact
old normalizedpayload hashes and unchanged inner rawtar manifests. This avoids
evidence deletion and further executable source transformations.

Caveat: initial missing-phase pair executable originals were overwritten by
receipt builds; their manifest hashes survive but byteexact hostbinary rebuild
failed twice (noGPUrun). First-source/failedbuildlogs retained separately; do
not claim original initial binaries retained. The actual phase-measured binaries
are retained byteexact with both problems,hitartifacts,receipts; identityaudit
applies to those. Initialpair exacthit PASS artifacts remain auditable.

Native caveat: QSB_LOCAL_SM86 disablesGLV11/P18, so timedlocaltable9.8GB
versus native22.7GB. The localbudget bound is not a measured4090bound. Native
phase profiling remains necessary before claiming its tableaxis dead; no native
GPU is available. No sourceaxis declared universally dead from localtiming.

Final retention PASS via iter48-final-audit.py. Cold historicalprocedures,
reviews, wrappers, audit-entrypoints and fullnotes moved losslessly to
iter48-cold-lab.tar.xz at originalnames/cold-before; hashmanifestchecked.
Byteexact tree originals stored as line-copy deltas, not source deletion.
Fulltokenizer corrected to preserve // inside stringliteral; 887057/882603
tokens identical. BCJ compression trial increasedsize, rejected; retained
ordinaryLZMA2+reversibleSASS. No further GPUtest after package-only changes.
