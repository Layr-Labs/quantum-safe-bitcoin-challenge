#!/usr/bin/env python3
"""Read back retained evidence and verify screen, disabled image, and package cap.
This is evidence integrity, not a GPU performance retry or candidate coverage proof.
"""
from pathlib import Path
import base64,gzip,hashlib,io,json,lzma,re,tarfile
from iter47_normalize_carriers import reconstruct
from iter47b_rawtar_codec import unpack
from iter47b_sass_codec import reconstruct as sass_reconstruct
lab=Path(__file__).resolve().parent;base=lab.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=lab/'iter47-joint-history.tar.xz';receipt=json.loads(p.with_suffix(p.suffix+'.json').read_text())
b=p.read_bytes();assert len(b)==receipt['bytes'] and sha(b)==receipt['sha256']
raw=lzma.decompress(b);assert len(raw)==receipt['raw_tar_bytes'] and sha(raw)==receipt['raw_tar_sha256']
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    def read_payload(name):
        if name in t.getnames(): return t.extractfile(name).read()
        if name+'.codec' in t.getnames(): return unpack(t.extractfile(name+'.codec').read(),sass_reconstruct)
        return reconstruct(t.extractfile(name+'.normalized').read())
    for n,v in receipt['records'].items():
        data=t.extractfile(n).read();assert len(data)==v['bytes'] and sha(data)==v['sha256'],n
    legacy=json.load(t.extractfile('legacy/legacy-source-gzip.json'))
    legacy_bytes=gzip.compress(t.extractfile('legacy/tree.cu.orig').read(),compresslevel=9,mtime=0)
    assert len(legacy_bytes)==legacy['bytes'] and sha(legacy_bytes)==legacy['sha256']
    # Verify every earlier nested member; no previous lossless evidence is dropped.
    for tarname,manifestname,key in [('iter45-lossless-history.tar.xz.rawtar','iter45-lossless-history.tar.xz.manifest.json','members'),('iter46-evidence.tar.xz.rawtar','iter46-evidence.tar.xz.manifest.json','records'),('iter47-evidence.rawtar','iter47-evidence.manifest.json','records'),('historical-loose-lab.rawtar','historical-loose-lab.manifest.json','records')]:
        payload=read_payload(tarname);manifest=json.loads(t.extractfile(manifestname).read())
        with tarfile.open(fileobj=io.BytesIO(payload)) as nested:
            for n,v in manifest[key].items():
                data=nested.extractfile(n).read();assert len(data)==v['bytes'] and sha(data)==v['sha256'],n
        if tarname=='iter47-evidence.rawtar':current=payload;cm=manifest
with tarfile.open(fileobj=io.BytesIO(current)) as t:
    findings=json.loads(t.extractfile('final/iter47-findings.json').read());hits=0
    for a in 'AB':
        score=json.load(t.extractfile(f'screen/p1-{a}.json'));run=json.load(t.extractfile(f'screen/p1-{a}.run.json'))
        assert score['metrics']['verified'] and len(run['hits'])==score['metrics']['verified_hits'];hits+=len(run['hits'])
        assert score['score']/1e6==findings['screen']['Mps'][a]
        wrapper=Path(findings['manifest'][a]['source']).stem
        assert sha(t.extractfile('measured/'+wrapper).read())==findings['manifest'][a]['binary_sha256']
    for route in ('native','local'):
        f=findings['emitted_census'][route];assert f['off_identity']['byteidentical_to_iter46']
        assert sha(t.extractfile(f'build/{route}-disabled.cubin').read())==f['off_identity']['sha256']
        assert all(f['unchanged_other_functions'].values())
    for rel in ['tree_karatsuba_sc.cuh','tests/gpu_epochs/filter_tail_sc.cuh','tests/gpu_epochs/tree.cu']:
        assert t.extractfile('source/'+rel).read()==(base/rel).read_bytes(),rel
    assert t.extractfile('build/tree-audit-unscaled.log').read()==t.extractfile('build/tree-audit-control.log').read()
    s=(base/'qsb_carrier_sm89.h').read_text().split('static const char *const qsb_carrier_b64[] = {',1)[1].split('};',1)[0]
    carrier=base64.b64decode(''.join(re.findall(r'"([A-Za-z0-9+/=]+)"',s)))
    assert sha(carrier)==findings['emitted_census']['native']['off_identity']['sha256']
assert hits==11997 and findings['screen']['delta_percent']<0
assert '#define QSB_TREE_KARATSUBA 1' not in (base/'subset.cu').read_text()
assert not any(p.is_symlink() for p in base.rglob('*'))
out={'retained_exact_verifier_PASS':True,'verified_hits':hits,'screen_percent':findings['screen']['delta_percent'],'lossless_all_prior_and_current_payload_hashes_PASS':True,'current_payload_members':len(cm['records']),'disabled_native_local_byteidentity_PASS':True,'measured_implementation_unchanged_PASS':True,'existing_unscaled_audit_differential_text_identity_PASS':True,'existing_audit_overall_PASS':False,'qualified':False,'experiment_enabled':False,'submission':'none; nonpositive production screen','package':'pending','limit_bytes':8388608}
f=lab/'iter47-final-audit.json'
for _ in range(8):
    f.write_text(json.dumps(out,indent=2)+'\n');n=sum(p.stat().st_size for p in base.rglob('*') if p.is_file());assert n<=8388608,n
    if out.get('package_bytes')==n:break
    out.update(package_bytes=n,package='PASS')
else:raise AssertionError('package size did not converge')
print(json.dumps(out,indent=2))
