## Iteration 47 — exact tree-product Karatsuba, negative production screen

Read standing orders and board before experiment; actual leader faf5422a,
753571538, efef868 (previous d7c57dd4 745663804, third 4cc9d2d8 736585478).
New arithmetic direction: QSB_TREE_KARATSUBA=1 replaces only the speculative
block-tree product schedule with subtractive Karatsuba. Full 512-bit reconstruction,
unchanged short-carry reducer; 48 vs64 raw limb products, no rejection guards.
Generator and new helper retained, default OFF; optional carrier knob empty OFF.

Pre-existing tree_audit initially exposed absent ISO_INVU startup. Unscaled
candidate/control runs have BYTE-IDENTICAL complete output logs (both exit1;
existing speculative edge failures, NOT overall canonical PASS). Canonical helper
98304 exact checks is unchanged, distributed roots8192 exact, zero status errors.
No universal product-oracle or hit-coverage proof claimed.

Native sm89 digest14520->15248 (+728), IMAD.WIDE3644->3468(-176), IADD3+609;
sm86 14576->15320(+744), IMAD.WIDE-176,IADD3+610. Native8Bstack8Bstores8Bloads;
local8Bstack12Bstores8Bloads. Both128regs24KiB. Other5kernels instruction-identical.
OFF native/local cubins BYTE-IDENTICAL to iter46 production; carrier unchanged.

One preregistered120s N24 production screen through existing iter34_ab.sh:
A418.841294 M/s6077hits, B408.995789 M/s5920hits, -2.350653%, both exact
benchmark PASS,11997hits total. No leader qualification, no noise rescue,
no submission. This does not justify declaring constant-operand Karatsuba dead,
but repeating the dynamic tree schedule is unsupported by emitted and measured
results. Tool package path failures fixed without any benchmark restart.

See lab/ITER47-KARATSUBA-REVIEW.md, iter47-findings.json and lossless history.
Root notebook left unchanged under manifest editable-path restriction.
