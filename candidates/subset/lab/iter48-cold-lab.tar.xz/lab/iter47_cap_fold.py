#!/usr/bin/env python3
"""Final lossless cap folding; reuse measured payload without a GPU rerun."""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
w=Path('/work/tmp/qsb-subset-iter47-karat');sha=lambda b:hashlib.sha256(b).hexdigest()
records={};rawpath=w/'iter47-joint-capped.rawtar'
with tarfile.open(w/'iter47-joint-history.tar.xz') as old,tarfile.open(rawpath,'w') as t:
    for m in old.getmembers():
        b=old.extractfile(m).read();records[m.name]={'bytes':len(b),'sha256':sha(b)}
        info=tarfile.TarInfo(m.name);info.size=len(b);t.addfile(info,io.BytesIO(b))
    for n in ('historical-loose-lab.rawtar','historical-loose-lab.manifest.json'):
        b=(w/n).read_bytes();records[n]={'bytes':len(b),'sha256':sha(b)}
        info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b))
raw=rawpath.read_bytes();b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}])
assert lzma.decompress(b)==raw
p=w/'iter47-joint-capped.tar.xz';p.write_bytes(b)
r={'bytes':len(b),'sha256':sha(b),'raw_tar_bytes':len(raw),'raw_tar_sha256':sha(raw),'records':records,'prior_payload_bytes_preserved':'PASS','current_payload_members':308,'historical_loose_lab_folded_losslessly':199,'compression':'LZMA2 9EXTREME 512MiB dictionary'}
p.with_suffix(p.suffix+'.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
