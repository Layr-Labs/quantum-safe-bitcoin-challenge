#!/usr/bin/env python3
"""Final cap fix: fold legacy inert raw source, preserve exact gzip reconstruction."""
from pathlib import Path
import io,tarfile,json,lzma,hashlib
w=Path('/work/tmp/qsb-subset-iter47-karat');sha=lambda b:hashlib.sha256(b).hexdigest();p=w/'iter47-normalized.tar.xz';r=json.load(open(str(p)+'.json'));out=io.BytesIO();records={}
with tarfile.open(p) as old,tarfile.open(fileobj=out,mode='w') as t:
    for m in old.getmembers():
        b=old.extractfile(m).read();i=tarfile.TarInfo(m.name);i.size=len(b);t.addfile(i,io.BytesIO(b));records[m.name]={'bytes':len(b),'sha256':sha(b)}
    for n in ['tree.cu.orig','legacy-source-gzip.json']:
        b=(w/n).read_bytes();i=tarfile.TarInfo('legacy/'+n);i.size=len(b);t.addfile(i,io.BytesIO(b));records[i.name]={'bytes':len(b),'sha256':sha(b)}
raw=out.getvalue();b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]);assert lzma.decompress(b)==raw
p=w/'iter47-final-history.tar.xz';p.write_bytes(b);r.update(bytes=len(b),sha256=sha(b),raw_tar_bytes=len(raw),raw_tar_sha256=sha(raw),records=records);Path(str(p)+'.json').write_text(json.dumps(r,indent=2)+'\n');print('final archive bytes',len(b))
