#!/usr/bin/env python3
"""Losslessly fold prior evidence and this measured negative screen into one xz.
Never discard prior payload bytes to meet cap. Build artifacts remain externally
until the replacement archive is read back and all hashes match.
"""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
w=Path('/work/tmp/qsb-subset-iter47-karat');lab=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
prior=lab/'iter46-joint-history.tar.xz'
(w/'before-joint-iter46.tar.xz').write_bytes(prior.read_bytes())
records={};rawpath=w/'iter47-joint.rawtar'
with tarfile.open(prior) as old,tarfile.open(rawpath,'w') as t:
    for m in old.getmembers():
        b=old.extractfile(m).read();records[m.name]={'bytes':len(b),'sha256':sha(b)}
        info=tarfile.TarInfo(m.name);info.size=len(b);t.addfile(info,io.BytesIO(b))
    for name,p in [('iter47-evidence.rawtar',w/'iter47-evidence.rawtar'),('iter47-evidence.manifest.json',w/'iter47-evidence.manifest.json')]:
        b=p.read_bytes();records[name]={'bytes':len(b),'sha256':sha(b)}
        info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b))
raw=rawpath.read_bytes()
filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]
b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=filters)
assert lzma.decompress(b)==raw
out=w/'iter47-joint-history.tar.xz';out.write_bytes(b)
r={'bytes':len(b),'sha256':sha(b),'raw_tar_bytes':len(raw),'raw_tar_sha256':sha(raw),'records':records,'prior_payload_bytes_preserved':'PASS','current_payload_members':len(json.loads((w/'iter47-evidence.manifest.json').read_text())['records']),'compression':'LZMA2 9EXTREME 512MiB dictionary'}
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for n,v in records.items():
        data=t.extractfile(n).read();assert len(data)==v['bytes'] and sha(data)==v['sha256'],n
out.with_suffix(out.suffix+'.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2),flush=True)
