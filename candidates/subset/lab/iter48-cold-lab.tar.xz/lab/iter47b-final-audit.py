#!/usr/bin/env python3
"""Retained verification and bit-exact evidence/source/cap audit, no GPU rerun."""
from pathlib import Path
import base64,gzip,hashlib,io,json,lzma,re,tarfile
from iter47b_rawtar_codec import unpack
from iter47b_sass_codec import reconstruct
from iter47_normalize_carriers import reconstruct as carrier_reconstruct
from iter47b_source_codec import compact
lab=Path(__file__).resolve().parent;base=lab.parent;sha=lambda b:hashlib.sha256(b).hexdigest()
p=lab/'iter47-joint-history.tar.xz';r=json.load(open(str(p)+'.json'));b=p.read_bytes();assert sha(b)==r['sha256'];raw=lzma.decompress(b);assert sha(raw)==r['raw_tar_sha256'];payloads={};counts={}
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    for n,v in r['records'].items():
        b=t.extractfile(n).read();assert len(b)==v['bytes'] and sha(b)==v['sha256'],n
    legacy=json.load(t.extractfile('legacy/legacy-source-gzip.json'))
    legacy_bytes=gzip.compress(t.extractfile('legacy/tree.cu.orig').read(),compresslevel=9,mtime=0)
    assert len(legacy_bytes)==legacy['bytes'] and sha(legacy_bytes)==legacy['sha256']
    for name in ('iter45-lossless-history.tar.xz.rawtar','iter46-evidence.tar.xz.rawtar','iter47-evidence.rawtar','iter47b-evidence.rawtar','historical-loose-lab.rawtar'):
        if name in t.getnames(): payloads[name]=t.extractfile(name).read()
        elif name+'.normalized' in t.getnames(): payloads[name]=carrier_reconstruct(t.extractfile(name+'.normalized').read())
        else: payloads[name]=unpack(t.extractfile(name+'.codec').read(),reconstruct)
        counts[name]=0
        with tarfile.open(fileobj=io.BytesIO(payloads[name])) as inner:
            if name=='iter47b-evidence.rawtar':manifest=json.load(t.extractfile('iter47b-evidence.manifest.json'))['records']
            elif name=='iter47-evidence.rawtar':manifest=json.load(t.extractfile('iter47-evidence.manifest.json'))['records']
            else:manifest=json.load(t.extractfile(name.replace('.rawtar','.manifest.json')))
            if 'members' in manifest:manifest=manifest['members']
            if 'records' in manifest:manifest=manifest['records']
            for n,v in manifest.items():
                b=inner.extractfile(n).read();assert sha(b)==v['sha256'] and len(b)==v['bytes'],n;counts[name]+=1
with tarfile.open(fileobj=io.BytesIO(payloads['iter47b-evidence.rawtar'])) as t:
    f=json.load(t.extractfile('final/iter47b-findings.json'));hits=0
    for a in 'AB':
        s=json.load(t.extractfile('screen/p1-'+a+'.json'));run=json.load(t.extractfile('screen/p1-'+a+'.run.json'));assert s['metrics']['verified'];assert len(run['hits'])==s['metrics']['verified_hits'];hits+=len(run['hits']);assert s['score']/1e6==f['screen']['Mps'][a]
        n=Path(f['manifest'][a]['source']).stem;assert sha(t.extractfile('measured/'+n).read())==f['manifest'][a]['binary_sha256']
    for route in ('native','local'):assert f['off_identity'][route]['byteidentical_to_iter47']
    n='tests/gpu_epochs/inverse_limbs.cuh';assert t.extractfile('source/'+n).read()==(base/n).read_bytes(),n
    n='tests/gpu_epochs/tree.cu';assert compact(t.extractfile('source/'+n).read().decode())==(base/n).read_text(),n
    assert f['existing_audit_complete_text_identical'] and not f['existing_audit_overall_PASS']
    assert hits==11209 and f['screen']['delta_percent']<0
assert '#define QSB_INVERSE_PACK_CARRY 1' not in (base/'subset.cu').read_text()
s=(base/'qsb_carrier_sm89.h').read_text().split('static const char *const qsb_carrier_b64[] = {',1)[1].split('};',1)[0];image=base64.b64decode(''.join(re.findall(r'"([A-Za-z0-9+/=]+)"',s)));assert sha(image)==f['off_identity']['native']['sha256']
o={'retained_exact_verifier_PASS':True,'verified_hits':hits,'screen_percent':f['screen']['delta_percent'],'lossless_prior_and_current_member_hashes_PASS':True,'member_counts':counts,'off_native_local_identity_PASS':True,'measured_source_identity_PASS':True,'qualified':False,'experiment_enabled':False,'submission':'none; negative production screen','package':'pending','limit_bytes':8388608}
p=lab/'iter47b-final-audit.json'
for _ in range(10):
    p.write_text(json.dumps(o,indent=2)+'\n');n=sum(x.stat().st_size for x in base.rglob('*') if x.is_file());assert n<=8388608,n
    if o.get('package_bytes')==n:break
    o.update(package_bytes=n,package='PASS')
else:raise AssertionError('package convergence')
print(json.dumps(o,indent=2))
