#!/usr/bin/env python3
"""Append second measured screen losslessly; flatten old archives and normalize new carriers."""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
from iter47_normalize_carriers import normalize,reconstruct
w=Path('/work/tmp/qsb-subset-iter47b-packedcarry');lab=Path(__file__).resolve().parent;base=lab.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
screen=Path(json.load(open(lab/'iter47b-findings.json'))['screen_artifacts']);files={}
for p in base.rglob('*'):
    if p.is_file() and p.suffix in ('.h','.cuh','.cu','.py','.sh'):
        files['source/'+p.relative_to(base).as_posix()]=p
for p in w.iterdir():
    if p.is_file() and p.suffix not in ('.xz',) and 'rawtar' not in p.name:files['build/'+p.name]=p
for p in screen.iterdir():
    if p.is_file():files['screen/'+p.name]=p
for n in ('n24L_iter37control','n24L_iter47packcarry'):
    files['measured/'+n]=lab/n;files['measured/.'+n+'.build']=lab/('.'+n+'.build')
for n in ('iter47b-findings.json','ITER47B-PACKED-CARRY-REVIEW.md'):files['final/'+n]=lab/n
files['build/retained-tree-audit-control.log']=Path('/work/tmp/qsb-subset-iter47-karat/tree-audit-control.log')
manifest={};out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w') as t:
    for name,p in sorted(files.items()):
        b=p.read_bytes();manifest[name]={'bytes':len(b),'sha256':sha(b)};info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b))
raw=out.getvalue();norm,count=normalize(raw);assert reconstruct(norm)==raw
(w/'iter47b-evidence.rawtar').write_bytes(raw);(w/'iter47b-evidence.manifest.json').write_text(json.dumps({'records':manifest},indent=2)+'\n')
outer=io.BytesIO();records={}
with tarfile.open(lab/'iter47-joint-history.tar.xz') as prior,tarfile.open(fileobj=outer,mode='w') as t:
    def add(name,b):
        info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b));records[name]={'bytes':len(b),'sha256':sha(b)}
    for m in prior.getmembers():add(m.name,prior.extractfile(m).read())
    add('iter47b-evidence.rawtar.normalized',norm);add('iter47b-evidence.manifest.json',(w/'iter47b-evidence.manifest.json').read_bytes())
raw=outer.getvalue();(w/'iter47b-joint.rawtar').write_bytes(raw)
b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]);assert lzma.decompress(b)==raw
p=w/'iter47b-joint-history.tar.xz';p.write_bytes(b);r={'bytes':len(b),'sha256':sha(b),'raw_tar_bytes':len(raw),'raw_tar_sha256':sha(raw),'records':records,'compression':'LZMA2 9EXTREME 512MiB','current_members':len(manifest),'previous_hashes_preserved':'PASS'}
Path(str(p)+'.json').write_text(json.dumps(r,indent=2)+'\n');print('Archive bytes',len(b),'members',len(manifest))
