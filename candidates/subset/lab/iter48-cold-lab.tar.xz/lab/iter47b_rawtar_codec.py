#!/usr/bin/env python3
"""Lossless rawtar member-header normalization with reversible body transforms."""
import hashlib,io,json,tarfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def pack(raw,transform=None):
    out=io.BytesIO();rows=[];position=0
    with tarfile.open(fileobj=io.BytesIO(raw)) as source,tarfile.open(fileobj=out,mode='w') as dest:
        def add(name,body):
            info=tarfile.TarInfo(name);info.size=len(body);dest.addfile(info,io.BytesIO(body))
        for k,member in enumerate(source.getmembers()):
            assert member.offset==position and member.offset_data==position+512 and member.isfile()
            header=raw[position:position+512];body=source.extractfile(member).read();original=body
            pad=(-len(body))%512;assert raw[member.offset_data+len(body):member.offset_data+len(body)+pad]==bytes(pad)
            kind='';converted=transform(member.name,body) if transform else None
            if converted:kind,body=converted
            canonical=bytearray(header);canonical[:100]=bytes(100);canonical[148:156]=b'        '
            rows.append({'header_rest':canonical[100:].hex(),'name':header[:100].hex(),'checksum':header[148:156].hex(),'bytes':len(original),'kind':kind})
            add(str(k),body);position=member.offset_data+len(original)+pad
        add('tail',raw[position:]);add('reconstruct.json',json.dumps({'sha256':sha(raw),'bytes':len(raw),'rows':rows},separators=(',',':')).encode())
    return out.getvalue()
def unpack(blob,transform=None):
    with tarfile.open(fileobj=io.BytesIO(blob)) as t:
        m=json.load(t.extractfile('reconstruct.json'));pieces=[]
        for k,row in enumerate(m['rows']):
            header=bytearray(bytes.fromhex(row['name'])+bytes.fromhex(row['header_rest']));header[148:156]=bytes.fromhex(row['checksum'])
            body=t.extractfile(str(k)).read()
            if row.get('kind'):
                assert transform is not None;body=transform(body)
            assert len(body)==row['bytes'];pieces.extend([bytes(header),body,bytes((-len(body))%512)])
        pieces.append(t.extractfile('tail').read());raw=b''.join(pieces)
        assert len(raw)==m['bytes'] and sha(raw)==m['sha256'];return raw
normalize=pack
reconstruct=unpack
