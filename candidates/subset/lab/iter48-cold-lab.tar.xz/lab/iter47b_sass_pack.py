#!/usr/bin/env python3
"""Cap-forced reversible SASS encoding normalization, no GPU rerun."""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
from iter47b_rawtar_codec import pack,unpack
from iter47b_sass_codec import normalize,reconstruct
from iter47_normalize_carriers import reconstruct as carrier_reconstruct
w=Path('/work/tmp/qsb-subset-iter47b-packedcarry');sha=lambda b:hashlib.sha256(b).hexdigest()
out=io.BytesIO();r=json.load(open(w/'iter47b-joint-history.tar.xz.json'));records={};counts={}
with tarfile.open(w/'iter47b-joint-history.tar.xz') as old,tarfile.open(fileobj=out,mode='w') as t:
    for m in old.getmembers():
        b=old.extractfile(m).read();n=m.name
        if n.endswith('rawtar') or n.endswith('rawtar.normalized'):
            raw=carrier_reconstruct(b) if n.endswith('.normalized') else b
            def trans(name,data):
                if name.endswith('.sass'):
                    v,count=normalize(data);assert reconstruct(v)==data;counts[name]=count;return 'sass_encoding',v
                return None
            b=pack(raw,trans);assert unpack(b,reconstruct)==raw
            n=n.removesuffix('.normalized')+'.codec'
        info=tarfile.TarInfo(n);info.size=len(b);t.addfile(info,io.BytesIO(b));records[n]={'bytes':len(b),'sha256':sha(b)}
raw=out.getvalue();(w/'iter47b-sass-joint.rawtar').write_bytes(raw)
b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]);assert lzma.decompress(b)==raw
p=w/'iter47b-sass-history.tar.xz';p.write_bytes(b);r.update(bytes=len(b),sha256=sha(b),raw_tar_bytes=len(raw),raw_tar_sha256=sha(raw),records=records,sass_encoding_normalized_members=len(counts));Path(str(p)+'.json').write_text(json.dumps(r,indent=2)+'\n');print('Final SASS-normalized archive',len(b),'members transformed',len(counts))
