#!/usr/bin/env python3
"""Audit exact retained screen, all historical payloads, source, off images and cap.
This is evidence integrity, not a performance rerun or a coverage proof.
"""
from pathlib import Path
import base64,gzip,hashlib,io,json,lzma,re,tarfile
from iter47_normalize_carriers import reconstruct
from iter47c_source_layout import layout
lab=Path(__file__).resolve().parent;base=lab.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=lab/'iter47-joint-history.tar.xz';r=json.load(open(str(p)+'.json'));b=p.read_bytes()
assert len(b)==r['bytes'] and sha(b)==r['sha256']
raw=lzma.decompress(b);assert len(raw)==r['raw_tar_bytes'] and sha(raw)==r['raw_tar_sha256']
payloads={};counts={}
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    assert set(t.getnames())==set(r['records'])
    for n,v in r['records'].items():
        b=t.extractfile(n).read();assert len(b)==v['bytes'] and sha(b)==v['sha256'],n
    legacy=json.load(t.extractfile('legacy/legacy-source-gzip.json'))
    b=gzip.compress(t.extractfile('legacy/tree.cu.orig').read(),compresslevel=9,mtime=0)
    assert len(b)==legacy['bytes'] and sha(b)==legacy['sha256']
    for name in ('iter45-lossless-history.tar.xz.rawtar','iter46-evidence.tar.xz.rawtar','iter47-evidence.rawtar','iter47b-evidence.rawtar','iter47c-evidence.rawtar','historical-loose-lab.rawtar'):
        payloads[name]=t.extractfile(name).read() if name in t.getnames() else reconstruct(t.extractfile(name+'.normalized').read())
        mn=name.replace('.rawtar','.manifest.json')
        manifest=json.load(t.extractfile(mn))
        manifest=manifest.get('members',manifest.get('records',manifest));counts[name]=len(manifest)
        with tarfile.open(fileobj=io.BytesIO(payloads[name])) as inner:
            assert set(inner.getnames())==set(manifest)
            for n,v in manifest.items():
                b=inner.extractfile(n).read();assert sha(b)==v['sha256'] and len(b)==v['bytes'],n
with tarfile.open(fileobj=io.BytesIO(payloads['iter47c-evidence.rawtar'])) as t:
    f=json.load(t.extractfile('final/iter47c-findings.json'));hits=0
    assert f==json.load(open(lab/'iter47c-findings.json'))
    for a in 'AB':
        s=json.load(t.extractfile('screen/p1-'+a+'.json'));run=json.load(t.extractfile('screen/p1-'+a+'.run.json'))
        assert s['metrics']['verified'];assert len(run['hits'])==s['metrics']['verified_hits'];hits+=len(run['hits'])
        assert s['score']/1e6==f['screen']['Mps'][a]
        n=Path(f['manifest'][a]['source']).stem
        assert sha(t.extractfile('measured/'+n).read())==f['manifest'][a]['binary_sha256']
        assert sha(t.extractfile('source/lab/'+n+'.cu').read())==f['manifest'][a]['source_sha256']
    for route in ('native','local'):
        b=t.extractfile(f'build/{route}-disabled.cubin').read()
        assert sha(b)==f['off_identity'][route]['sha256']
        with tarfile.open(fileobj=io.BytesIO(payloads['iter47b-evidence.rawtar'])) as old:
            assert b==old.extractfile(f'build/{route}-disabled.cubin').read()
        assert f['off_identity'][route]['byteidentical_to_iter47']
        for name,row in f['emitted'][route].items():
            assert row['identical'] == ('kernel_build_gtable' not in name)
        assert sum('kernel_build_gtable' not in n for n in f['emitted'][route])==5
    # Deterministic layout preserves strings, line counts and attribution.
    # Full originals remain available for measured source/image reproduction.
    for m in t.getmembers():
        if m.name.startswith('source/') and Path(m.name).suffix in ('.h','.cuh','.cu','.cpp'):
            n=m.name[7:];original=t.extractfile(m).read();current=(base/n).read_bytes()
            transformed=layout(original.decode(),n=='CpuGrindSubset.h',n).encode() if Path(n).suffix in ('.h','.cuh','.cu') else original
            assert transformed==current,n
            assert original.count(b'\n')==current.count(b'\n'),n
    assert json.load(t.extractfile('build/prefix-count.json'))==f['dynamic_work_census']
    assert hits==11412 and f['screen']['delta_percent']<0
    assert not f['qualified'] and not f['enabled_default']
with tarfile.open(lab/'iter47c-package-identity.tar.xz') as identity:
    report=json.load(identity.extractfile('identity.json'))
    for n,v in report['records'].items():
        b=identity.extractfile(n).read();assert len(b)==v['bytes'] and sha(b)==v['sha256']
    for row in report['preprocessed'].values():
        assert row['before_token_sha256']==row['after_token_sha256']
        assert row['token_count']>800000
    for route in ('native','local'):
        assert report['disabled_cubins'][route]['sha256']==f['off_identity'][route]['sha256']
        assert report['disabled_cubins'][route]['byteidentity_PASS']
    for n,v in report['changed_source'].items():
        assert sha((base/n).read_bytes())==v['after_sha256'],n
s=(base/'qsb_carrier_sm89.h').read_text().split('static const char *const qsb_carrier_b64[] = {',1)[1].split('};',1)[0]
image=base64.b64decode(''.join(re.findall(r'"([A-Za-z0-9+/=]+)"',s)))
assert sha(image)==f['off_identity']['native']['sha256']
assert '#define QSB_GT_PREFIX_CACHE 1' not in (base/'subset.cu').read_text()
assert re.search(r'#ifndef QSB_GT_PREFIX_CACHE\s+#define QSB_GT_PREFIX_CACHE 0', (base/'tests/gpu_epochs/tree.cu').read_text())
assert not any(p.is_symlink() for p in base.rglob('*'))
o={'retained_exact_verifier_PASS':True,'verified_hits':hits,'screen_percent':f['screen']['delta_percent'],'lossless_all_prior_and_current_member_hashes_PASS':True,'member_counts':counts,'off_native_local_identity_PASS':True,'measured_source_identity_PASS':True,'qualified':False,'experiment_enabled':False,'submission':'none; negative production screen','package':'pending','limit_bytes':8388608}
p=lab/'iter47c-final-audit.json'
for _ in range(10):
    p.write_text(json.dumps(o,indent=2)+'\n');n=sum(x.stat().st_size for x in base.rglob('*') if x.is_file());assert n<=8388608,n
    if o.get('package_bytes')==n:break
    o.update(package_bytes=n,package='PASS')
else:raise AssertionError('package convergence')
print(json.dumps(o,indent=2))
