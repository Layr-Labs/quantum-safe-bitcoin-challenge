#!/usr/bin/env python3
"""Losslessly append a third distinct measured screen, preserving earlier records."""
from pathlib import Path
import argparse,hashlib,io,json,lzma,tarfile
from iter47_normalize_carriers import normalize,reconstruct
ap=argparse.ArgumentParser();ap.add_argument('workdir',type=Path);args=ap.parse_args()
w=args.workdir;lab=Path(__file__).resolve().parent;base=lab.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
f=json.load(open(lab/'iter47c-findings.json'));screen=Path(f['screen_artifacts']);files={}
for p in base.rglob('*'):
    if p.is_file() and p.suffix in ('.h','.cuh','.cu','.py','.sh','.cpp'):
        files['source/'+p.relative_to(base).as_posix()]=p
for n in ('tree.cu','local-cache-build.log','native-cache-build.log','local-cache.sass','native-cache.sass','native-cache.cubin','local-disabled.cubin','native-disabled.cubin','local-disabled-build.log','native-disabled-build.log','prefix-census','prefix-count.json','emitted-census.json','board-selected.txt','current-leader-note.md'):
    files['build/'+n]=w/n
for p in screen.iterdir():
    if p.is_file():files['screen/'+p.name]=p
for n in ('n24L_iter37control','n24L_iter47gtcache'):
    files['measured/'+n]=lab/n;files['measured/.'+n+'.build']=lab/('.'+n+'.build')
for n in ('iter47c-findings.json','ITER47C-GTABLE-PREFIX-REVIEW.md'):
    files['final/'+n]=lab/n
manifest={};out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w') as t:
    for name,p in sorted(files.items()):
        b=p.read_bytes();manifest[name]={'bytes':len(b),'sha256':sha(b)}
        info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b))
raw=out.getvalue();norm,count=normalize(raw);assert reconstruct(norm)==raw
(w/'iter47c-evidence.rawtar').write_bytes(raw)
man=json.dumps({'records':manifest},indent=2).encode()+b'\n'
(w/'iter47c-evidence.manifest.json').write_bytes(man)
outer=io.BytesIO();records={}
with tarfile.open(lab/'iter47-joint-history.tar.xz') as prior,tarfile.open(fileobj=outer,mode='w') as t:
    def add(name,b):
        info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b))
        records[name]={'bytes':len(b),'sha256':sha(b)}
    for m in prior.getmembers():add(m.name,prior.extractfile(m).read())
    add('iter47c-evidence.rawtar.normalized',norm);add('iter47c-evidence.manifest.json',man)
raw=outer.getvalue();(w/'iter47c-joint.rawtar').write_bytes(raw)
b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]);assert lzma.decompress(b)==raw
p=w/'iter47c-joint-history.tar.xz';p.write_bytes(b)
r={'bytes':len(b),'sha256':sha(b),'raw_tar_bytes':len(raw),'raw_tar_sha256':sha(raw),'records':records,'compression':'LZMA2 9EXTREME 512MiB','current_members':len(manifest),'previous_hashes_preserved':'PASS'}
Path(str(p)+'.json').write_text(json.dumps(r,indent=2)+'\n')
print('Archive bytes',len(b),'members',len(manifest))
print('Projected package bytes',sum(x.stat().st_size for x in base.rglob('*') if x.is_file())-(lab/'iter47-joint-history.tar.xz').stat().st_size+len(b)-sum((lab/n).stat().st_size for n in ('n24L_iter37control','n24L_iter47gtcache','.n24L_iter37control.build','.n24L_iter47gtcache.build')))
