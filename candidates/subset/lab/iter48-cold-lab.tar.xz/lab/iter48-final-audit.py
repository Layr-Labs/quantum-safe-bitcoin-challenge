#!/usr/bin/env python3
"""Verify current diagnostic, every old payload, source identities, and package cap."""
from pathlib import Path
import base64,gzip,hashlib,io,json,lzma,re,tarfile
from iter47_normalize_carriers import reconstruct
from iter47b_sass_codec import reconstruct as sass_reconstruct
from iter48_source_delta import decode as source_decode
from iter47c_source_layout import layout,comments
lab=Path(__file__).resolve().parent;base=lab.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=lab/'iter47-joint-history.tar.xz';r=json.load(open(str(p)+'.json'));b=p.read_bytes()
assert sha(b)==r['sha256'] and len(b)==r['bytes']
raw=lzma.decompress(b);assert sha(raw)==r['raw_tar_sha256'] and len(raw)==r['raw_tar_bytes']
payloads={};counts={}
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
    assert set(t.getnames())==set(r['records'])
    for n,v in r['records'].items():
        b=t.extractfile(n).read();assert sha(b)==v['sha256'] and len(b)==v['bytes'],n
    legacy=json.load(t.extractfile('legacy/legacy-source-gzip.json'))
    b=gzip.compress(t.extractfile('legacy/tree.cu.orig').read(),compresslevel=9,mtime=0)
    assert sha(b)==legacy['sha256'] and len(b)==legacy['bytes']
    for name in ('iter45-lossless-history.tar.xz.rawtar','iter46-evidence.tar.xz.rawtar','iter47-evidence.rawtar','iter47b-evidence.rawtar','iter47c-evidence.rawtar','historical-loose-lab.rawtar','iter48-evidence.rawtar'):
        if name in t.getnames(): payloads[name]=t.extractfile(name).read()
        else:
            n=name+'.normalized'
            if n in t.getnames(): blob=t.extractfile(n).read()
            else:
                blob=sass_reconstruct(t.extractfile(n+'.sass').read());original=json.load(t.extractfile(n+'.sass-original.json'))
                assert len(blob)==original['bytes'] and sha(blob)==original['sha256'],n
            payloads[name]=reconstruct(blob)
        manifest=json.load(t.extractfile(name.replace('.rawtar','.manifest.json')))
        manifest=manifest.get('members',manifest.get('records',manifest));counts[name]=len(manifest)
        with tarfile.open(fileobj=io.BytesIO(payloads[name])) as inner:
            assert set(inner.getnames())==set(manifest)
            for n,v in manifest.items():
                b=inner.extractfile(n).read();assert sha(b)==v['sha256'] and len(b)==v['bytes'],n
with tarfile.open(fileobj=io.BytesIO(payloads['iter48-evidence.rawtar'])) as t:
    f=json.load(t.extractfile('final/iter48-findings.json'));assert f==json.load(open(lab/'iter48-findings.json'));hits=0
    for i,key in [(0,'production'),(1,'prefix_cache')]:
        s=json.load(t.extractfile(f'diagnostic/receipt{i}.score.json'));run=json.load(t.extractfile(f'diagnostic/receipt{i}.run.json'))
        assert s['metrics']['verified'];assert len(run['hits'])==s['metrics']['verified_hits']==f[key]['verified_hits']
        assert s['score']/1e6==f[key]['verified_Mps'];hits+=len(run['hits'])
        assert sha(t.extractfile(f'measured/n24L_iter48audit{i}').read())==f['measured_binary_sha256'][str(i)]
        phase=dict(re.findall(r'(\w+)=([^ ]+)',t.extractfile(f'diagnostic/phase{i}.txt').read().decode().strip()))
        assert phase['sha256']==f[key]['sha256'] and int(phase['table_bytes'])==f[key]['table_bytes']
        assert phase['build_heal_spot']=='PASS'
        for k in ('ladders_s','kernel_s','heal_s','spot_s','total_s'):assert float(phase[k])==f[key][k]
    assert hits==5182 and f['production']['sha256']==f['prefix_cache']['sha256']
    assert not f['qualified'] and f['diagnostic_scores_are_not_qualification']
    assert t.extractfile('diagnostic/tree-measured.cu').read()==(base/'tests/gpu_epochs/tree.cu').read_bytes()
    for m in t.getmembers():
        if m.name.startswith('before-compaction/'):
            rel=m.name[len('before-compaction/'):];a=t.extractfile(m).read();b=(base/rel).read_bytes()
            assert comments(a.decode()).encode()==b and a.count(b'\n')==b.count(b'\n'),rel
    before={m.name[len('before-compaction/'):]:t.extractfile(m).read() for m in t.getmembers() if m.name.startswith('before-compaction/')}
with tarfile.open(lab/'iter48-target-before.tar.xz') as t:before['tests/gpu_epochs/tree.cu']=source_decode((base/'tests/gpu_epochs/tree.cu').read_bytes(),t.extractfile('tests/gpu_epochs/tree.cu.delta.json').read())
# Prior measured-source -> prior package layout exactly; then current diagnostics/comment-only transform.
with tarfile.open(fileobj=io.BytesIO(payloads['iter47c-evidence.rawtar'])) as t:
    old=json.load(t.extractfile('final/iter47c-findings.json'));assert old==json.load(open(lab/'iter47c-findings.json'))
    cold=tarfile.open(lab/'iter48-cold-lab.tar.xz');cold_names=set(cold.getnames())
    for m in t.getmembers():
        if m.name.startswith('source/') and Path(m.name).suffix in ('.h','.cuh','.cu','.cpp'):
            rel=m.name[7:];a=t.extractfile(m).read();expected=layout(a.decode(),rel=='CpuGrindSubset.h',rel).encode() if Path(rel).suffix in ('.h','.cuh','.cu') else a
            current=before.get(rel)
            if current is None:current=cold.extractfile(rel).read() if rel in cold_names else (base/rel).read_bytes()
            assert expected==current,rel
    cold.close()
    for a in 'AB':
        s=json.load(t.extractfile('screen/p1-'+a+'.json'));run=json.load(t.extractfile('screen/p1-'+a+'.run.json'));assert s['metrics']['verified'] and len(run['hits'])==s['metrics']['verified_hits']
for name in ('iter47c-package-identity.tar.xz','iter48-package-identity.tar.xz'):
    with tarfile.open(lab/name) as t:
        report=json.load(t.extractfile('identity.json'))
        for n,v in report['records'].items():
            b=t.extractfile(n).read();assert sha(b)==v['sha256'] and len(b)==v['bytes']
        if name.startswith('iter48'):
            for row in report['preprocessed'].values():assert row['equal'] and row['tokens']>800000
            for sm,row in report['off_identity'].items():assert row['equal'] and row['sha256']==f['off_identity'][sm]['sha256']
        else:
            for row in report['preprocessed'].values():assert row['before_token_sha256']==row['after_token_sha256']
with tarfile.open(lab/'iter48-cold-lab.tar.xz') as t:
    cold_manifest=json.load(t.extractfile('manifest.json'))
    assert set(t.getnames())==set(cold_manifest)|{'manifest.json'}
    for n,v in cold_manifest.items():
        b=t.extractfile(n).read();assert len(b)==v['bytes'] and sha(b)==v['sha256'],n
s=(base/'qsb_carrier_sm89.h').read_text();body=s.split('static const char *const qsb_carrier_b64[] = {',1)[1].split('};',1)[0]
image=base64.b64decode(''.join(re.findall(r'"([A-Za-z0-9+/=]+)"',body)));assert sha(image)==f['off_identity']['sm89']['sha256']
assert re.search(r'#ifndef QSB_GT_PHASE_AUDIT\s+#define QSB_GT_PHASE_AUDIT 0',(base/'tests/gpu_epochs/tree.cu').read_text())
assert not any(p.is_symlink() for p in base.rglob('*'))
o={'independent_existing_benchmark_exact_PASS':True,'verified_diagnostic_hits':hits,'repaired_table_9803211584B_identity_PASS':True,'all_prior_and_current_payload_hashes_PASS':True,'member_counts':counts,'prior_measured_source_and_package_compaction_PASS':True,'disabled_sm89_sm86_byte_identity_PASS':True,'qualified':False,'submission':'none; diagnostic only','package':'pending','limit_bytes':8388608}
p=lab/'iter48-final-audit.json'
for _ in range(10):
    p.write_text(json.dumps(o,indent=2)+'\n');n=sum(x.stat().st_size for x in base.rglob('*') if x.is_file());assert n<=8388608,n
    if o.get('package_bytes')==n:break
    o.update(package_bytes=n,package='PASS')
else:raise AssertionError('package convergence')
print(json.dumps(o,indent=2))
