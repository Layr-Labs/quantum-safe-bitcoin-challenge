#!/usr/bin/env python3
"""Append exact diagnostic evidence; leave previous rawtar payloads unchanged."""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
from iter47_normalize_carriers import normalize,reconstruct
lab=Path(__file__).resolve().parent;base=lab.parent;w=Path('/work/tmp/qsb-subset-iter48-phases')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for name in ('build0.log','build1.log','receipt-build0.log','receipt-build1.log','receipt0.full.log','receipt1.full.log','receipt0.score.json','receipt1.score.json','receipt0.run.json','receipt1.run.json','phase0.txt','phase1.txt','off89.cubin','off86.cubin','off89.build.log','off86.build.log','tree-measured.cu'):
    files['diagnostic/'+name]=(w/name).read_bytes()
for p in w.glob('problem[01]/*'):files['diagnostic/'+p.relative_to(w).as_posix()]=p.read_bytes()
for n in ('n24L_iter48audit0','n24L_iter48audit1','.n24L_iter48audit0.build','.n24L_iter48audit1.build','n24L_iter48audit0.cu','n24L_iter48audit1.cu'):
    files['measured/'+n]=(lab/n).read_bytes()
# Retain the initial cryptographic PASS pair without phase receipts, not a timing result.
screen=next(Path('/work/tmp/qsb-subset-iter34absdiff').glob('iter48-isolated-phase-diagnostic-*'))
for p in screen.iterdir():
    if p.is_file():files['first-missing-receipts/'+p.name]=p.read_bytes()
for n in ('iter48-findings.json','ITER48-GTABLE-PHASE-REVIEW.md','iter48-retain.py'):
    files['final/'+n]=(lab/n).read_bytes()
for p in sorted((w/'before-source').rglob('*')):
    if p.is_file():files['before-compaction/'+p.relative_to(w/'before-source').as_posix()]=p.read_bytes()
records={};out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w') as t:
    for n,b in sorted(files.items()):
        r=tarfile.TarInfo(n);r.size=len(b);t.addfile(r,io.BytesIO(b));records[n]={'bytes':len(b),'sha256':sha(b)}
raw=out.getvalue();norm,count=normalize(raw);assert reconstruct(norm)==raw
(w/'iter48-evidence.rawtar').write_bytes(raw)
manifest=(json.dumps({'records':records},indent=2)+'\n').encode()
outer=io.BytesIO();rows={}
with tarfile.open(lab/'iter47-joint-history.tar.xz') as prior,tarfile.open(fileobj=outer,mode='w') as t:
    def add(n,b):
        i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b));rows[n]={'bytes':len(b),'sha256':sha(b)}
    for m in prior.getmembers():add(m.name,prior.extractfile(m).read())
    add('iter48-evidence.rawtar.normalized',norm);add('iter48-evidence.manifest.json',manifest)
raw=outer.getvalue();b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]);assert lzma.decompress(b)==raw
p=w/'iter48-joint-history.tar.xz';p.write_bytes(b)
r={'bytes':len(b),'sha256':sha(b),'raw_tar_bytes':len(raw),'raw_tar_sha256':sha(raw),'records':rows,'compression':'LZMA2 9EXTREME 512MiB','current_members':len(records),'previous_hashes_preserved':'PASS'}
old=json.load(open(str(lab/'iter47-joint-history.tar.xz')+'.json'))
for n,v in old['records'].items():assert rows[n]==v,n
Path(str(p)+'.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS previous payload hashes, measured binaries, exact hit artifacts retained',len(records),'members',len(b),'compressed bytes')
