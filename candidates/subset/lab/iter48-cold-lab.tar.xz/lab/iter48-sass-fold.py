#!/usr/bin/env python3
"""Lossless encoding normalization of SASS text in historical carriers; raw bytes recoverable."""
from pathlib import Path
import hashlib,io,json,lzma,tarfile
from iter47b_sass_codec import normalize,reconstruct
w=Path('/work/tmp/qsb-subset-iter48-phases');sha=lambda b:hashlib.sha256(b).hexdigest();rows={};out=io.BytesIO();count=0
with tarfile.open(w/'iter48-joint-history.tar.xz') as old,tarfile.open(fileobj=out,mode='w') as t:
    for m in old.getmembers():
        b=old.extractfile(m).read();n=m.name
        if n.endswith('.normalized') and b.count(b'/* 0x'):
            v,k=normalize(b);assert reconstruct(v)==b;count+=k
            receipt=json.dumps({'bytes':len(b),'sha256':sha(b)}).encode();i=tarfile.TarInfo(n+'.sass-original.json');i.size=len(receipt);t.addfile(i,io.BytesIO(receipt));rows[i.name]={'bytes':len(receipt),'sha256':sha(receipt)}
            b=v;n+='.sass'
        i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b));rows[n]={'bytes':len(b),'sha256':sha(b)}
raw=out.getvalue();b=lzma.compress(raw,format=lzma.FORMAT_XZ,filters=[{'id':lzma.FILTER_LZMA2,'preset':9|lzma.PRESET_EXTREME,'dict_size':512<<20}]);assert lzma.decompress(b)==raw
p=w/'iter48-sass-history.tar.xz';p.write_bytes(b)
r={'bytes':len(b),'sha256':sha(b),'raw_tar_bytes':len(raw),'raw_tar_sha256':sha(raw),'records':rows,'compression':'LZMA2 9EXTREME 512MiB reversible SASS codec','current_members':56,'previous_payloads_reconstructible':'PASS','sass_words':count};Path(str(p)+'.json').write_text(json.dumps(r,indent=2)+'\n');print(len(b),'bytes,',count,'SASS words reversible')
