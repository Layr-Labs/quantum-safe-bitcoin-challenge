#!/usr/bin/env python3
"""Lossless line-copy delta, base is measured current tree retained in joint archive."""
import difflib,hashlib,json
sha=lambda b:hashlib.sha256(b).hexdigest()
def encode(base,body):
 a=base.splitlines(keepends=True);b=body.splitlines(keepends=True);ops=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
  if tag=='equal':ops.append(['copy',i,j])
  elif tag!='delete':ops.append(['text',b''.join(b[k:l]).decode()])
 return json.dumps({'base_sha256':sha(base),'sha256':sha(body),'bytes':len(body),'ops':ops},separators=(',',':')).encode()
def decode(base,blob):
 r=json.loads(blob);assert sha(base)==r['base_sha256'];lines=base.splitlines(keepends=True);out=[]
 for op in r['ops']:
  out.append(b''.join(lines[op[1]:op[2]]) if op[0]=='copy' else op[1].encode())
 b=b''.join(out);assert sha(b)==r['sha256'] and len(b)==r['bytes'];return b
if __name__=='__main__':
 from pathlib import Path
 import io,tarfile
 lab=Path(__file__).resolve().parent;base=(lab.parent/'tests/gpu_epochs/tree.cu').read_bytes()
 for name in ('iter48-target-before.tar.xz','iter48-first-capture-source.tar.xz'):
  p=lab/name;files={}
  with tarfile.open(p) as t:
   for m in t.getmembers():
    b=t.extractfile(m).read();n=m.name
    if n.endswith('.cu'):v=encode(base,b);assert decode(base,v)==b;b=v;n+='.delta.json'
    files[n]=b
  with tarfile.open(p,'w:xz',preset=9) as t:
   for n,b in files.items():i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
  print(name,p.stat().st_size)
