#!/usr/bin/env python3
"""Lossless global factoring of CUDA's 128-bit SASS comments, including control."""
import hashlib,io,json,re,struct,tarfile
sha=lambda b:hashlib.sha256(b).hexdigest()
pat=re.compile(rb'/\* (0x[0-9a-f]{16}) \*/')
def pack(blob):
    out=io.BytesIO();pool={};words=[];recipes={}
    with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
        for m in t.getmembers():
            b=t.extractfile(m).read()
            if m.name.endswith('.sass'):
                inner=io.BytesIO()
                with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
                    text=it.extractfile('text').read();parts=[];idx=[];lens=[];pos=0
                    for x in pat.finditer(text):
                        parts.append(text[pos:x.start(1)]);lens.append(len(parts[-1]));pos=x.end(1)
                        w=bytes.fromhex(x[1][2:].decode())
                        if w not in pool:pool[w]=len(words);words.append(w)
                        idx.append(pool[w])
                    parts.append(text[pos:]);lens.append(len(parts[-1]))
                    recipes[m.name]={'lengths':lens,'sha256':sha(text)}
                    for a in it.getmembers():
                        z=it.extractfile(a).read()
                        if a.name=='text':z=b''.join(parts)
                        a.size=len(z);ot.addfile(a,io.BytesIO(z))
                    z=struct.pack('<'+'I'*len(idx),*idx);a=tarfile.TarInfo('control-indices');a.size=len(z);ot.addfile(a,io.BytesIO(z))
                b=inner.getvalue()
            m.size=len(b);dest.addfile(m,io.BytesIO(b))
        for n,z in [('control-pool',b''.join(words)),('control-recipes',json.dumps(recipes,separators=(',',':')).encode())]:
            a=tarfile.TarInfo(n);a.size=len(z);dest.addfile(a,io.BytesIO(z))
    return out.getvalue()
def unpack(blob):
    out=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as ot:
        pool=t.extractfile('control-pool').read();recipes=json.load(t.extractfile('control-recipes'))
        for m in t.getmembers():
            if m.name in ('control-pool','control-recipes'):continue
            b=t.extractfile(m).read()
            if m.name in recipes:
                inner=io.BytesIO()
                with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as dest:
                    text=it.extractfile('text').read();indices=it.extractfile('control-indices').read();r=recipes[m.name];parts=[];pos=0
                    for i,n in enumerate(r['lengths']):
                        parts.append(text[pos:pos+n]);pos+=n
                        if i+1<len(r['lengths']):
                            x=struct.unpack_from('<I',indices,i*4)[0];parts.append(b'0x'+pool[x*8:x*8+8].hex().encode())
                    text=b''.join(parts);assert sha(text)==r['sha256']
                    for a in it.getmembers():
                        if a.name=='control-indices':continue
                        z=text if a.name=='text' else it.extractfile(a).read();a.size=len(z);dest.addfile(a,io.BytesIO(z))
                b=inner.getvalue()
            m.size=len(b);ot.addfile(m,io.BytesIO(b))
    return out.getvalue()
