#!/usr/bin/env python3
"""Lossless byte-plane transform of SASS-word archives; preserves old rawtar."""
import hashlib,io,json,tarfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def transform(blob,inverse=False):
    out=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
        for m in t.getmembers():
            b=t.extractfile(m).read()
            if m.name.endswith('.sass'):
                inner=io.BytesIO()
                with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
                    for a in it.getmembers():
                        z=it.extractfile(a).read()
                        if a.name=='words':
                            assert len(z)%8==0; n=len(z)//8
                            if inverse:
                                v=bytearray(len(z))
                                for i in range(8):v[i::8]=z[i*n:(i+1)*n]
                                z=bytes(v)
                            else:z=b''.join(z[i::8] for i in range(8))
                        ot.addfile(a,io.BytesIO(z))
                b=inner.getvalue();m.size=len(b)
            dest.addfile(m,io.BytesIO(b))
    return out.getvalue()
