#!/usr/bin/env python3
"""Exact global repeated-line dictionary for retained SASS text; no lossy pruning."""
import io,json,struct,tarfile

def pack(blob):
 out=io.BytesIO();pool={};lines=[]
 with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
  for m in t.getmembers():
   b=t.extractfile(m).read()
   if m.name.endswith('.sass'):
    inner=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
     for a in it.getmembers():
      z=it.extractfile(a).read()
      if a.name=='text':
       ids=[]
       for line in z.splitlines(keepends=True):
        if line not in pool:pool[line]=len(lines);lines.append(line)
        ids.append(pool[line])
       z=struct.pack('<'+'I'*len(ids),*ids)
      a.size=len(z);ot.addfile(a,io.BytesIO(z))
    b=inner.getvalue()
   m.size=len(b);dest.addfile(m,io.BytesIO(b))
  z=b''.join(struct.pack('<I',len(l))+l for l in lines);a=tarfile.TarInfo('global-line-pool');a.size=len(z);dest.addfile(a,io.BytesIO(z))
 return out.getvalue()

def unpack(blob):
 out=io.BytesIO()
 with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
  pool=t.extractfile('global-line-pool').read();lines=[];pos=0
  while pos<len(pool):
   n=struct.unpack_from('<I',pool,pos)[0];pos+=4;lines.append(pool[pos:pos+n]);pos+=n
  for m in t.getmembers():
   if m.name=='global-line-pool':continue
   b=t.extractfile(m).read()
   if m.name.endswith('.sass'):
    inner=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
     for a in it.getmembers():
      z=it.extractfile(a).read()
      if a.name=='text':z=b''.join(lines[i] for (i,) in struct.iter_unpack('<I',z))
      a.size=len(z);ot.addfile(a,io.BytesIO(z))
    b=inner.getvalue()
   m.size=len(b);dest.addfile(m,io.BytesIO(b))
 return out.getvalue()
