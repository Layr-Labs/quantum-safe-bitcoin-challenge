#!/usr/bin/env python3
"""Lossless split SASS instruction/control streams, pooled exact 64-bit words."""
import io,struct,tarfile

def pack(blob):
 out=io.BytesIO();pool={};words=[]
 with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
  for m in t.getmembers():
   b=t.extractfile(m).read()
   if m.name.endswith('.sass'):
    inner=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
     for a in it.getmembers():
      z=it.extractfile(a).read()
      if a.name=='words':
       idx=[[],[]]
       for i in range(0,len(z),8):
        w=z[i:i+8]
        if w not in pool:pool[w]=len(words);words.append(w)
        idx[(i//8)%2].append(pool[w])
       z=struct.pack('<I',len(idx[0]))+b''.join(struct.pack('<I',x) for g in idx for x in g)
      a.size=len(z);ot.addfile(a,io.BytesIO(z))
    b=inner.getvalue()
   m.size=len(b);dest.addfile(m,io.BytesIO(b))
  z=b''.join(words);a=tarfile.TarInfo('global-word-pool');a.size=len(z);dest.addfile(a,io.BytesIO(z))
 return out.getvalue()

def unpack(blob):
 out=io.BytesIO()
 with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
  pool=t.extractfile('global-word-pool').read()
  for m in t.getmembers():
   if m.name=='global-word-pool':continue
   b=t.extractfile(m).read()
   if m.name.endswith('.sass'):
    inner=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
     for a in it.getmembers():
      z=it.extractfile(a).read()
      if a.name=='words':
       n=struct.unpack_from('<I',z)[0];ids=[x[0] for x in struct.iter_unpack('<I',z[4:])];v=[]
       for i in range(n):
        for j in [i,i+n]:
         if j<len(ids):v.append(pool[ids[j]*8:ids[j]*8+8])
       z=b''.join(v)
      a.size=len(z);ot.addfile(a,io.BytesIO(z))
    b=inner.getvalue()
   m.size=len(b);dest.addfile(m,io.BytesIO(b))
 return out.getvalue()
