#!/usr/bin/env python3
"""Reversible global exact-word dictionary for existing SASS word streams."""
import io,json,struct,tarfile

def pack(blob):
    pool={};words=[];out=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
        for m in t.getmembers():
            b=t.extractfile(m).read()
            if m.name.endswith('.sass'):
                inner=io.BytesIO()
                with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
                    for a in it.getmembers():
                        z=it.extractfile(a).read()
                        if a.name=='words':
                            ids=[]
                            for i in range(0,len(z),8):
                                w=z[i:i+8]
                                if w not in pool:pool[w]=len(words);words.append(w)
                                ids.append(pool[w])
                            z=struct.pack('<'+'I'*len(ids),*ids)
                        a.size=len(z);ot.addfile(a,io.BytesIO(z))
                b=inner.getvalue()
            m.size=len(b);dest.addfile(m,io.BytesIO(b))
        z=b''.join(words);a=tarfile.TarInfo('global-word-pool');a.size=len(z);dest.addfile(a,io.BytesIO(z))
    return out.getvalue()
def unpack(blob):
    out=io.BytesIO()
    with tarfile.open(fileobj=io.BytesIO(blob)) as t,tarfile.open(fileobj=out,mode='w') as dest:
        pool=t.extractfile('global-word-pool').read()
        for m in t.getmembers():
            if m.name=='global-word-pool':continue
            b=t.extractfile(m).read()
            if m.name.endswith('.sass'):
                inner=io.BytesIO()
                with tarfile.open(fileobj=io.BytesIO(b)) as it,tarfile.open(fileobj=inner,mode='w') as ot:
                    for a in it.getmembers():
                        z=it.extractfile(a).read()
                        if a.name=='words':z=b''.join(pool[i*8:i*8+8] for (i,) in struct.iter_unpack('<I',z))
                        a.size=len(z);ot.addfile(a,io.BytesIO(z))
                b=inner.getvalue()
            m.size=len(b);dest.addfile(m,io.BytesIO(b))
    return out.getvalue()
