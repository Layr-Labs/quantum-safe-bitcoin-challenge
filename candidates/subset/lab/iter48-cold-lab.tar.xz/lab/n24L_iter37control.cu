/* Iter37: matched sm86 front3 ABI screen. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#include "../subset.cu"
