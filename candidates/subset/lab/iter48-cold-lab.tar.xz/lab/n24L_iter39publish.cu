/* Iter39: one common A/B publication ABI in existing shared allocation. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_FRONT3_PUBLISH_AB 1
#include "../subset.cu"
