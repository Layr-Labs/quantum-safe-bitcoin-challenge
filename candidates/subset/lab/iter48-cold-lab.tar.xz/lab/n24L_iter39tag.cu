/* Iter39 mode2: one shared address/tag, callee-owned arena selection. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_FRONT3_PUBLISH_AB 2
#include "../subset.cu"
