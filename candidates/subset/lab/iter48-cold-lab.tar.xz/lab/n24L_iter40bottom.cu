/* Iter40: remove last tree publication/barrier, replicate bottom multiply. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_TREE_BOTTOM_FUSE 1
#include "../subset.cu"
