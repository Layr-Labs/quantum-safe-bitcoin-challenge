/* Actual promoted efef868 is source-identical to 569839c except REDRAW.
 * Local sm86 adaptation matches the retained, hashed executable. */
#define QSB_LOCAL_SM86 1
#define QSB_GLV11 0
#define QSB_Q_P18 0
#define QSB_Q_MIX 0
#define QSB_GLV_ZDEC 0
#define QSB_S3_NM_MASK 0
#define QSB_S3_NM_SEED 0
#define QSB_GATHER_ONE_FORM 0
#define QSB_DECODE_CUT 0
#include "/work/tmp/qsb-subset-iter34absdiff/current-leader/candidates/subset/subset.cu"
