/* Iter41: adjacent leaf ownership, one parent MUL, shuffle publication. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_TREE_BOTTOM_SHFL 1
#include "../subset.cu"
