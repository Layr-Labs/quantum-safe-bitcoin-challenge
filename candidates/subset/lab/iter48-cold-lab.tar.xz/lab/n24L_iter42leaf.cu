/* Iter42: preserve front ownership/locality; permute only inversion leaves. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_TREE_LEAF_SHFL 1
#include "../subset.cu"
