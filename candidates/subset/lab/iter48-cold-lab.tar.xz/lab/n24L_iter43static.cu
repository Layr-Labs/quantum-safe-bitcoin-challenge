/* Iter43: rolled CTA128 inverse tree, fixed-size address arithmetic only. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_TREE_STATIC_N 1
#include "../subset.cu"
