/* Iter45: fixed-layout addresses with dynamic rolled tree loop bounds. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_TREE_CONST_ADDR 1
#include "../subset.cu"
