/* Iter46: guarded high-half-only degree6/13 parity carry approximation. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_PW_HI_APPROX 1
#include "../subset.cu"
