/* Iter47c exact per-batch high-ladder prefix reuse in startup table build only. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_GT_PREFIX_CACHE 1
#include "../subset.cu"
