/* Iter47: exact subtractive-Karatsuba product at speculative tree seam only. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_TREE_KARATSUBA 1
#include "../subset.cu"
