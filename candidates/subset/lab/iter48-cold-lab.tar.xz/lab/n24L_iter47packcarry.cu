/* Iter47b exact packed segmented root carry lookahead; no carry approximation. */
#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_INVERSE_PACK_CARRY 1
#include "../subset.cu"
