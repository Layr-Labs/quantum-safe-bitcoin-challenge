#define QSB_LOCAL_SM86 1
#define QSB_CARRIER_BUILD 1
#define QSB_GT_PHASE_AUDIT 1
#define QSB_GT_PREFIX_CACHE 0
#include "../subset.cu"
