#define QSB_LATE_POINT_CONSTANTS 1
#include "../../subset.cu"
