#define QSB_LATE_POINT_CONSTANTS 1
#define QSB_POINT_MIN_BLOCKS 3
#include "../../subset.cu"
