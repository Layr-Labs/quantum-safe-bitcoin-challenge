// Diagnostic split of the promoted paired consumer. Same pairing and tree order.
#pragma once
__device__ __forceinline__ void qsb_split_store(uint64_t *work, uint8_t *valid,
        unsigned stride, unsigned index, const QsbPairFront3 &front) {
    valid[index]=(uint8_t)front.ok;
    #pragma unroll
    for(int j=0;j<16;j++) work[(size_t)j*stride+index]=front.ok?front.words[j]:(j==0?1:0);
}

// Hash output temporarily occupies the four eventual denominator words.
// Point threads read all four inputs before replacing their own record.
#ifndef QSB_POINT_MIN_BLOCKS
#define QSB_POINT_MIN_BLOCKS 2
#endif
__global__ void __launch_bounds__(256,2) kernel_split_sha(const uint32_t *first,
        uint64_t *work, unsigned epochs, unsigned stride) {
    const unsigned tid=threadIdx.x,lane=tid&(QSB_SE_WINDOWS-1);
    const unsigned ea=QSB_PAIR_MUL*blockIdx.x+2*(tid/QSB_SE_WINDOWS);
    if(ea>=epochs)return;
    const bool hasB=ea+1<epochs;
    const uint32_t *fa=first+(size_t)ea*QSB_FIRST_SLOTS*8;
    const uint32_t *fb=hasB?fa+QSB_FIRST_SLOTS*8:fa;
    const QsbPairEpochZ z=qsb_pair_epoch_z_value(fa,fb,lane);
    const unsigned ia=ea*QSB_SE_WINDOWS+lane;
    #pragma unroll
    for(int j=0;j<4;j++){
        work[(size_t)j*stride+ia]=z.a[j];
        if(hasB)work[(size_t)j*stride+ia+QSB_SE_WINDOWS]=z.b[j];
    }
}
#ifndef QSB_LATE_POINT_CONSTANTS
#define QSB_LATE_POINT_CONSTANTS 0
#endif
#if QSB_LATE_POINT_CONSTANTS
// QSB_U2R is initialized before the scan and remains immutable throughout it.
// Keep the same field chain, loading its final preparation inputs afterward.
__device__ __noinline__ QsbPairFront3 qsb_late_point_front(
        uint64_t z0,uint64_t z1,uint64_t z2,uint64_t z3,const uint8_t *gtable){
    uint64_t z[4]={z0,z1,z2,z3};
    uint64_t qx[4],qy[4],qzz[4],qzzz[4];
    uint32_t unused_flag=0;
    qsb_filter_chain_trial(qx,qy,qzz,qzzz,z,gtable,unused_flag);
    uint64_t rx[4]={QSB_U2R[0],QSB_U2R[1],QSB_U2R[2],QSB_U2R[3]};
    uint64_t ry[4]={QSB_U2R[4],QSB_U2R[5],QSB_U2R[6],QSB_U2R[7]};
    uint64_t prod[5],n[12];QsbPairFront3 out;
    qsb_xyzz_finish_prepare_f(qx,qzz,qzzz,rx,prod);
    qsb_k2s_pre3(qy,qzz,qzzz,ry,n);
    out.ok=(prod[0]|prod[1]|prod[2]|prod[3])!=0;
    Load256(out.words,prod);
    #pragma unroll
    for(int j=0;j<12;j++)out.words[4+j]=n[j];
    return out;
}
#endif
__global__ void __launch_bounds__(256,QSB_POINT_MIN_BLOCKS) kernel_split_point(
        const uint8_t *gtable, uint64_t *work, uint8_t *valid, unsigned stride) {
    const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=stride)return;
    uint64_t z[4];
    #pragma unroll
    for(int j=0;j<4;j++)z[j]=work[(size_t)j*stride+i];
#if QSB_LATE_POINT_CONSTANTS
    QsbPairFront3 f=qsb_late_point_front(z[0],z[1],z[2],z[3],gtable);
#else
    QsbPairFront3 f=qsb_pair_front3_z_value(z[0],z[1],z[2],z[3],gtable,
        QSB_U2R[0],QSB_U2R[1],QSB_U2R[2],QSB_U2R[3],QSB_U2R[4],QSB_U2R[5],QSB_U2R[6],QSB_U2R[7]);
#endif
    qsb_split_store(work,valid,stride,i,f);
}

// Four factors per leaf; all block lanes participate with identity padding.
#define QSB_SPLIT_INVERSE_EPOCHS (4u * (QSB_SE_BLOCK / QSB_SE_WINDOWS))
__global__ void __launch_bounds__(256,2) kernel_split_inverse4(uint64_t *work,unsigned epochs,unsigned stride){
    const unsigned tid=threadIdx.x,lane=tid&(QSB_SE_WINDOWS-1);
    const unsigned ea=QSB_SPLIT_INVERSE_EPOCHS*blockIdx.x+4*(tid/QSB_SE_WINDOWS);
    const unsigned ia=ea*QSB_SE_WINDOWS+lane;
    uint64_t a[5]={1,0,0,0,0},b[5]={1,0,0,0,0},c[5]={1,0,0,0,0},d[5]={1,0,0,0,0};
    uint64_t left[5],right[5],leaf[5],il[5],ir[5],inv[5];
    #pragma unroll
    for(int j=0;j<4;j++){
        if(ea<epochs)a[j]=work[(size_t)j*stride+ia];
        if(ea+1<epochs)b[j]=work[(size_t)j*stride+ia+QSB_SE_WINDOWS];
        if(ea+2<epochs)c[j]=work[(size_t)j*stride+ia+2*QSB_SE_WINDOWS];
        if(ea+3<epochs)d[j]=work[(size_t)j*stride+ia+3*QSB_SE_WINDOWS];
    }
    QSB_TREE_MUL(left,a,b);
    QSB_TREE_MUL(right,c,d);
    QSB_TREE_MUL(leaf,left,right);
    qsb_block_inverse_tree(leaf);
    QSB_TREE_MUL(il,leaf,right);
    QSB_TREE_MUL(ir,leaf,left);
    if(ea<epochs){QSB_TREE_MUL(inv,il,b);
        #pragma unroll
        for(int j=0;j<4;j++)work[(size_t)j*stride+ia]=inv[j];}
    if(ea+1<epochs){QSB_TREE_MUL(inv,il,a);
        #pragma unroll
        for(int j=0;j<4;j++)work[(size_t)j*stride+ia+QSB_SE_WINDOWS]=inv[j];}
    if(ea+2<epochs){QSB_TREE_MUL(inv,ir,d);
        #pragma unroll
        for(int j=0;j<4;j++)work[(size_t)j*stride+ia+2*QSB_SE_WINDOWS]=inv[j];}
    if(ea+3<epochs){QSB_TREE_MUL(inv,ir,c);
        #pragma unroll
        for(int j=0;j<4;j++)work[(size_t)j*stride+ia+3*QSB_SE_WINDOWS]=inv[j];}
}
__global__ void __launch_bounds__(256,2) kernel_split_tail(const uint64_t *work,
        const uint8_t *valid,unsigned stride,const epoch_desc_t *epochs,uint8_t *hitbuf){
    const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=stride || !valid[i])return;
    uint64_t n[12],v[4];
    #pragma unroll
    for(int j=0;j<12;j++)n[j]=work[(size_t)(j+4)*stride+i];
    #pragma unroll
    for(int j=0;j<4;j++)v[j]=work[(size_t)j*stride+i];
    const int encoded=qsb_pair_tail3_value(n[0],n[1],n[2],n[3],n[4],n[5],n[6],n[7],n[8],n[9],n[10],n[11],
        v[0],v[1],v[2],v[3],QSB_U2R[0],QSB_U2R[1],QSB_U2R[2],QSB_U2R[3],QSB_U2R[4],QSB_U2R[5],QSB_U2R[6],QSB_U2R[7]);
    if(encoded){
        const unsigned slot=atomicAdd((uint32_t*)hitbuf,1);
        if(slot<1024){
            uint8_t *record=hitbuf+4+(size_t)slot*ZLAB_HIT_REC;
            *(uint32_t*)record=i|((uint32_t)(encoded-1)<<30);
            const unsigned e=i/QSB_SE_WINDOWS,lane=i&(QSB_SE_WINDOWS-1);
            for(int j=0;j<6;j++)record[4+j]=epochs[e].early[j];
            for(int j=0;j<3;j++)record[10+j]=WIN3[lane][j];
        }
    }
}
