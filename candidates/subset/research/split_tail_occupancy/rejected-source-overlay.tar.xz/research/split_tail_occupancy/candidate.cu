#define QSB_TAIL_MIN_BLOCKS 3
#include "../../subset.cu"
